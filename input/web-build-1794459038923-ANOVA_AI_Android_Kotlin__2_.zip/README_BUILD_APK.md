# ANOVA AI — Security Hardening & Signed APK Build Guide

**Brand:** ANOVA edits  
**Creator:** Anas Memon (Tharushah, Sindh, Pakistan)

## 1. Security & Google Play Protect Audit Fixes Applied
1. **Removed `BIND_ACCESSIBILITY_SERVICE` & Window Content Reading**: `AnovaAccessibilityService` (`canRetrieveWindowContent`, `canPerformGestures`, `ACTION_SET_TEXT`) was removed from earlier versions because combining Accessibility screen reading/injection with internet access is a primary malware heuristic in Google Play Protect.
2. **Minimal Least-Privilege Permissions Only**: Declared **only** `INTERNET`, `RECORD_AUDIO`, and `VIBRATE`. Removed `CALL_PHONE`, `READ_CONTACTS`, `SET_ALARM`, `POST_NOTIFICATIONS`, and `ACCESS_NETWORK_STATE`. Phone calls and WhatsApp actions launch safely via user-confirmed system intents (`Intent.ACTION_DIAL`, `https://wa.me/`).
3. **Foreground-Only Microphone Usage**: `MainActivity` observes `Lifecycle.Event.ON_STOP` and immediately stops speech recognition, `MediaRecorder`, and TTS whenever the app is backgrounded or the screen turns off.
4. **Strict HTTPS / System CA Trust Only**: `res/xml/network_security_config.xml` sets `cleartextTrafficPermitted="false"` with only `<certificates src="system" />` (no `<certificates src="user" />` and no cleartext domain exceptions). `OkHttpClient` permits only `MODERN_TLS` and `COMPATIBLE_TLS`, and backend URLs must use `https://`.
5. **Disabled Backup & Data Extraction**: Configured `android:allowBackup="false"`, `android:fullBackupContent="false"`, and `res/xml/data_extraction_rules.xml`.
6. **Clean Official Dependencies Only**: Uses only official AndroidX Jetpack Compose, OkHttp 4.12.0, and Kotlin Coroutines — zero trackers, ad SDKs, dynamic DEX loading, or native binaries.
7. **Note on Play Protect & Signing**: Never attempt to disable or bypass Google Play Protect. Always build a properly signed release APK with a private release keystore (never distribute `app-debug.apk` signed with Android's public debug key).

## 2. Backend URL Configuration (Important for APK vs AI Studio Preview)
- Inside AI Studio Preview (`ais-dev-...`), requests pass through a browser cookie/iframe proxy (`/__cookie_check.html`). An installed Android APK does **not** have browser preview cookies, and `ais-pre-...` returns `HTTP 404` until the backend is deployed publicly (`npm run build && npm start` with `GEMINI_API_KEY` set on the server).
- Never embed `GEMINI_API_KEY` inside the APK.
- Deploy the Node.js backend (`server.ts` + `dist/`) publicly (e.g., Cloud Run with unauthenticated invocation, or any HTTPS Node host), then either:
  - Build with `-PANOVA_BACKEND_URL="https://your-deployed-url"`, **or**
  - Open **Settings -> Backend Server Connection** inside the installed Android app, enter your `https://` deployed URL, and tap **Test Backend & Gemini Connection**.

## 3. Generate a Real Release Signing Keystore
Run once inside `/android-app`:
```bash
keytool -genkeypair -v \
  -keystore anova-release.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias anova_release
```
Copy `keystore.properties.example` to `keystore.properties` and enter your keystore passwords.

## 4. Build & Verify a Properly Signed APK (Android 7.1.1+ / API 25+)
```bash
./gradlew clean assembleRelease
```
Or for local USB debugging only:
```bash
./gradlew clean assembleDebug
```
Verify APK v2/v3 signature and print the SHA-256 certificate fingerprint (needed for Play Protect appeals):
```bash
apksigner verify --verbose --print-certs app/build/outputs/apk/release/app-release.apk
```

## 5. Install & Test on Android 7.1.1+
```bash
adb install -r app/build/outputs/apk/release/app-release.apk
```

## 6. Submitting an Official Google Play Protect Appeal (If Falsely Flagged)
- Official form: `https://support.google.com/googleplay/android-developer/contact/protectappeals`
- Package ID: `com.anasmemon.anova`
- App Name: `ANOVA AI` (ANOVA edits, Created by Anas Memon)
- Include the APK SHA-256 hash, signing certificate SHA-256 fingerprint from `apksigner verify --print-certs`, and note that the app uses only `INTERNET`, `RECORD_AUDIO`, and `VIBRATE` for user-initiated foreground voice AI queries over HTTPS.

