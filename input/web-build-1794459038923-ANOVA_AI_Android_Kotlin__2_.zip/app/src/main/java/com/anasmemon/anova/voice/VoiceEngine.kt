package com.anasmemon.anova.voice

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.PlaybackParams
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.util.Locale
import java.util.UUID
import kotlin.math.pow

enum class VoiceGender {
    FEMALE,
    MALE
}

class VoiceEngine(private val context: Context) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private var speechRecognizer: SpeechRecognizer? = null
    private var mediaRecorder: MediaRecorder? = null
    private var recorderFile: File? = null
    private var recorderMimeType: String = "audio/mp4"
    private var recorderPollRunnable: Runnable? = null
    private var isRecordingFallback = false
    private var useDirectAudioFallback = false
    private var recognizerClientErrors = 0

    private var tts: TextToSpeech? = null
    private var mediaPlayer: MediaPlayer? = null
    private var ttsReady = false
    private var pendingFallbackText: String? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var audioFocusRequest: AudioFocusRequest? = null
    private var speakWatchdogRunnable: Runnable? = null

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted

    private val _audioLevel = MutableStateFlow(0f)
    val audioLevel: StateFlow<Float> = _audioLevel

    var voiceGender: VoiceGender = VoiceGender.FEMALE
    var languagePreference: String = "auto"
    var voiceSpeed: Float = 1.08f
    var voicePitchSemitones: Int = 0
    var continuousConversation: Boolean = true
    var conversationActive: Boolean = false

    private var onSpeechRecognized: ((String) -> Unit)? = null
    private var onAudioCaptured: ((ByteArray, String) -> Unit)? = null
    private var onSpeechError: ((String) -> Unit)? = null

    private val focusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
            stopSpeaking()
        }
    }

    init {
        initTextToSpeech()
    }

    @Suppress("DEPRECATION")
    private fun requestAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = audioFocusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setOnAudioFocusChangeListener(focusChangeListener)
                .build()
                .also { audioFocusRequest = it }
            am.requestAudioFocus(req)
        } else {
            am.requestAudioFocus(
                focusChangeListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
        } else {
            am.abandonAudioFocus(focusChangeListener)
        }
    }

    private fun cancelSpeakWatchdog() {
        speakWatchdogRunnable?.let { mainHandler.removeCallbacks(it) }
        speakWatchdogRunnable = null
    }

    private fun armSpeakWatchdog(timeoutMs: Long, onTimeout: () -> Unit) {
        cancelSpeakWatchdog()
        val r = Runnable {
            if (_isSpeaking.value) {
                onTimeout()
            }
        }
        speakWatchdogRunnable = r
        mainHandler.postDelayed(r, timeoutMs)
    }

    private fun initTextToSpeech() {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                applyVoiceProfile()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                        _audioLevel.value = 0.65f
                    }

                    override fun onDone(utteranceId: String?) {
                        cancelSpeakWatchdog()
                        _isSpeaking.value = false
                        _audioLevel.value = 0f
                        abandonAudioFocus()
                        scheduleAutoResumeListening(320)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        cancelSpeakWatchdog()
                        _isSpeaking.value = false
                        _audioLevel.value = 0f
                        abandonAudioFocus()
                        scheduleAutoResumeListening(420)
                    }
                })
                pendingFallbackText?.let { queued ->
                    pendingFallbackText = null
                    speakViaDeviceTts(queued)
                }
            }
        }
    }

    fun resumeConversationIfActive(delayMs: Long = 350L) {
        scheduleAutoResumeListening(delayMs)
    }

    private fun scheduleAutoResumeListening(delayMs: Long) {
        if (continuousConversation && conversationActive && !_isMuted.value) {
            mainHandler.postDelayed({
                if (conversationActive && !_isMuted.value && !_isSpeaking.value && !_isListening.value) {
                    startListeningInternal()
                }
            }, delayMs)
        }
    }

    private fun resolveTargetLocale(): Locale {
        return when (languagePreference) {
            "ur" -> Locale("ur", "PK")
            "hi" -> Locale("hi", "IN")
            "sd" -> Locale("sd", "PK")
            "en" -> Locale.US
            else -> Locale.getDefault()
        }
    }

    private fun applyVoiceProfile() {
        val engine = tts ?: return
        val desiredLocale = resolveTargetLocale()
        val langStatus = try {
            engine.setLanguage(desiredLocale)
        } catch (_: Exception) {
            TextToSpeech.LANG_NOT_SUPPORTED
        }

        // Android 7.1 OEM TTS engines often lack Urdu/Sindhi packs; fall back cleanly so speech stays audible
        val activeLocale = if (
            langStatus == TextToSpeech.LANG_MISSING_DATA ||
            langStatus == TextToSpeech.LANG_NOT_SUPPORTED
        ) {
            val fallbackLocale = if (desiredLocale.language == "ur" || desiredLocale.language == "sd") {
                val hiStatus = engine.setLanguage(Locale("hi", "IN"))
                if (hiStatus >= TextToSpeech.LANG_AVAILABLE) Locale("hi", "IN") else Locale.US
            } else {
                Locale.US
            }
            engine.setLanguage(fallbackLocale)
            fallbackLocale
        } else {
            desiredLocale
        }

        try {
            val voices = engine.voices ?: emptySet()
            val desiredFemale = voiceGender == VoiceGender.FEMALE
            val preferred = voices
                .filter { it.locale.language == activeLocale.language }
                .sortedByDescending { it.quality }
                .firstOrNull { voice ->
                    val name = voice.name.lowercase(Locale.ROOT)
                    if (desiredFemale) {
                        name.contains("female") || name.contains("-f") || name.contains("sfg")
                    } else {
                        name.contains("male") || name.contains("-m") || name.contains("iom")
                    }
                }
            if (preferred != null) {
                engine.voice = preferred
            }
        } catch (_: Exception) {
            // Ignore Android 7.1 OEM voice enumeration quirks
        }

        val desiredFemale = voiceGender == VoiceGender.FEMALE
        val basePitch = if (desiredFemale) 1.08f else 0.86f
        val semitoneRatio = 2.0.pow(voicePitchSemitones / 12.0).toFloat()
        engine.setPitch((basePitch * semitoneRatio).coerceIn(0.6f, 1.5f))
        engine.setSpeechRate(voiceSpeed.coerceIn(0.85f, 1.35f))
    }

    fun updateProfile(
        gender: VoiceGender,
        language: String,
        speed: Float,
        pitchSemitones: Int
    ) {
        voiceGender = gender
        languagePreference = language
        voiceSpeed = speed.coerceIn(0.85f, 1.35f)
        voicePitchSemitones = pitchSemitones.coerceIn(-4, 4)
        applyVoiceProfile()
    }

    fun setGender(gender: VoiceGender) {
        voiceGender = gender
        applyVoiceProfile()
    }

    fun setMuted(muted: Boolean) {
        _isMuted.value = muted
        if (muted) {
            stopSpeaking()
        } else if (conversationActive && !_isListening.value && !_isSpeaking.value) {
            mainHandler.postDelayed({ startListeningInternal() }, 180)
        }
    }

    fun configureCallbacks(
        onResult: (String) -> Unit,
        onAudioCaptured: (ByteArray, String) -> Unit,
        onError: (String) -> Unit
    ) {
        this.onSpeechRecognized = onResult
        this.onAudioCaptured = onAudioCaptured
        this.onSpeechError = onError
    }

    fun startListening() {
        conversationActive = true
        mainHandler.post {
            stopSpeaking()
            startListeningInternal()
        }
    }

    private fun startListeningInternal() {
        if (!conversationActive) return

        if (useDirectAudioFallback || !SpeechRecognizer.isRecognitionAvailable(context)) {
            startMediaRecorderCapture()
            return
        }

        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _isListening.value = true
                }

                override fun onBeginningOfSpeech() {
                    _isListening.value = true
                }

                override fun onRmsChanged(rmsdB: Float) {
                    val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                    _audioLevel.value = normalized
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    _isListening.value = false
                    _audioLevel.value = 0f
                }

                override fun onError(error: Int) {
                    _isListening.value = false
                    _audioLevel.value = 0f
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                            scheduleAutoResumeListening(450)
                        }
                        SpeechRecognizer.ERROR_CLIENT,
                        SpeechRecognizer.ERROR_SERVER,
                        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
                        SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> {
                            recognizerClientErrors += 1
                            if (recognizerClientErrors >= 1) {
                                useDirectAudioFallback = true
                                startMediaRecorderCapture()
                            } else {
                                scheduleAutoResumeListening(600)
                            }
                        }
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                            conversationActive = false
                            onSpeechError?.invoke("Microphone permission is required.")
                        }
                        SpeechRecognizer.ERROR_AUDIO -> {
                            onSpeechError?.invoke("Audio recording error. Switching to backup mic...")
                            useDirectAudioFallback = true
                            scheduleAutoResumeListening(700)
                        }
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> {
                            // Network SpeechRecognizer failed -> switch to Gemini multimodal audio upload
                            useDirectAudioFallback = true
                            startMediaRecorderCapture()
                        }
                        else -> {
                            onSpeechError?.invoke("Speech recognition interrupted (code $error). Retrying...")
                            scheduleAutoResumeListening(800)
                        }
                    }
                }

                override fun onResults(results: Bundle?) {
                    recognizerClientErrors = 0
                    _isListening.value = false
                    _audioLevel.value = 0f
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spokenText = matches?.firstOrNull()?.trim().orEmpty()
                    if (spokenText.isNotEmpty()) {
                        onSpeechRecognized?.invoke(spokenText)
                    } else {
                        scheduleAutoResumeListening(350)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val targetTag = resolveTargetLocale().toLanguageTag()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            if (languagePreference != "auto") {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, targetTag)
            }
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, targetTag)
            putExtra(
                "android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES",
                arrayOf("en-US", "ur-PK", "hi-IN", "sd-IN", "sd-PK", "ar-SA")
            )
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {
            useDirectAudioFallback = true
            startMediaRecorderCapture()
        }
    }

    private data class RecorderProfile(
        val ext: String,
        val mime: String,
        val outputFormat: Int,
        val encoder: Int,
        val sampleRate: Int,
        val bitRate: Int
    )

    private fun startMediaRecorderCapture() {
        if (!conversationActive || isRecordingFallback) return
        stopMediaRecorderOnly(discard = true)

        val profiles = listOf(
            RecorderProfile(".m4a", "audio/mp4", MediaRecorder.OutputFormat.MPEG_4, MediaRecorder.AudioEncoder.AAC, 16000, 64000),
            RecorderProfile(".m4a", "audio/mp4", MediaRecorder.OutputFormat.MPEG_4, MediaRecorder.AudioEncoder.AAC, 44100, 96000),
            RecorderProfile(".3gp", "audio/3gpp", MediaRecorder.OutputFormat.THREE_GPP, MediaRecorder.AudioEncoder.AMR_NB, 8000, 12200)
        )

        var started = false
        var lastError: Exception? = null

        for (profile in profiles) {
            val outFile = File(context.cacheDir, "anova_voice_${System.currentTimeMillis()}${profile.ext}")
            var candidate: MediaRecorder? = null
            try {
                candidate = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    MediaRecorder(context)
                } else {
                    @Suppress("DEPRECATION")
                    MediaRecorder()
                }
                candidate.apply {
                    setAudioSource(MediaRecorder.AudioSource.MIC)
                    setOutputFormat(profile.outputFormat)
                    setAudioEncoder(profile.encoder)
                    setAudioChannels(1)
                    setAudioSamplingRate(profile.sampleRate)
                    setAudioEncodingBitRate(profile.bitRate)
                    setOutputFile(outFile.absolutePath)
                    prepare()
                    start()
                }
                mediaRecorder = candidate
                recorderFile = outFile
                recorderMimeType = profile.mime
                started = true
                break
            } catch (e: Exception) {
                lastError = e
                try {
                    candidate?.reset()
                    candidate?.release()
                } catch (_: Exception) {
                }
                outFile.delete()
            }
        }

        if (!started) {
            isRecordingFallback = false
            _isListening.value = false
            _audioLevel.value = 0f
            onSpeechError?.invoke("Microphone capture failed: ${lastError?.message ?: "Audio hardware unavailable"}")
            return
        }

        isRecordingFallback = true
        _isListening.value = true

        val startedAt = System.currentTimeMillis()
        var speechSeen = false
        var silenceSince = 0L

        val pollRunnable = object : Runnable {
            override fun run() {
                if (!isRecordingFallback || !conversationActive) return
                val amp = try {
                    mediaRecorder?.maxAmplitude ?: 0
                } catch (_: Exception) {
                    0
                }
                _audioLevel.value = (amp / 12000f).coerceIn(0f, 1f)
                val now = System.currentTimeMillis()

                if (amp > 1400) {
                    speechSeen = true
                    silenceSince = 0L
                } else if (speechSeen) {
                    if (silenceSince == 0L) {
                        silenceSince = now
                    } else if (now - silenceSince > 1100L) {
                        finishMediaRecorderCapture(dispatch = true)
                        return
                    }
                }

                if (now - startedAt > 12000L) {
                    finishMediaRecorderCapture(dispatch = speechSeen)
                    return
                }

                mainHandler.postDelayed(this, 120L)
            }
        }
        recorderPollRunnable = pollRunnable
        mainHandler.postDelayed(pollRunnable, 150L)
    }

    private fun finishMediaRecorderCapture(dispatch: Boolean) {
        val file = recorderFile
        val mime = recorderMimeType
        stopMediaRecorderOnly(discard = false)
        _isListening.value = false
        _audioLevel.value = 0f

        if (dispatch && file != null && file.exists() && file.length() > 1200) {
            try {
                val bytes = file.readBytes()
                file.delete()
                onAudioCaptured?.invoke(bytes, mime)
                return
            } catch (_: Exception) {
            }
        }
        file?.delete()
        scheduleAutoResumeListening(300)
    }

    private fun stopMediaRecorderOnly(discard: Boolean) {
        isRecordingFallback = false
        recorderPollRunnable?.let { mainHandler.removeCallbacks(it) }
        recorderPollRunnable = null
        mediaRecorder?.let { rec ->
            try {
                rec.stop()
            } catch (_: Exception) {
            }
            try {
                rec.reset()
                rec.release()
            } catch (_: Exception) {
            }
        }
        mediaRecorder = null
        if (discard) {
            recorderFile?.delete()
            recorderFile = null
        }
    }

    fun stopListening() {
        conversationActive = false
        mainHandler.post {
            _isListening.value = false
            _audioLevel.value = 0f
            if (isRecordingFallback) {
                stopMediaRecorderOnly(discard = true)
            }
            try {
                speechRecognizer?.stopListening()
            } catch (_: Exception) {
            }
        }
    }

    fun speak(text: String, audioBase64Wav: String? = null) {
        if (text.isBlank()) {
            scheduleAutoResumeListening(250)
            return
        }
        if (_isMuted.value) {
            scheduleAutoResumeListening(350)
            return
        }

        if (!audioBase64Wav.isNullOrBlank()) {
            playBackendWav(audioBase64Wav, text)
            return
        }

        mainHandler.post {
            if (!ttsReady) {
                pendingFallbackText = text
                // Watchdog in case OEM TTS engine never fires onInit
                mainHandler.postDelayed({
                    if (!ttsReady && pendingFallbackText != null) {
                        pendingFallbackText = null
                        _isSpeaking.value = false
                        scheduleAutoResumeListening(300)
                    }
                }, 3500L)
                return@post
            }
            speakViaDeviceTts(text)
        }
    }

    private fun speakViaDeviceTts(text: String) {
        requestAudioFocus()
        applyVoiceProfile()
        val utteranceId = UUID.randomUUID().toString()
        val estMs = (text.length * 90L + 3500L).coerceAtMost(28000L)
        armSpeakWatchdog(estMs) {
            try {
                tts?.stop()
            } catch (_: Exception) {
            }
            _isSpeaking.value = false
            _audioLevel.value = 0f
            abandonAudioFocus()
            scheduleAutoResumeListening(350)
        }
        val res = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId) ?: TextToSpeech.ERROR
        if (res == TextToSpeech.ERROR) {
            cancelSpeakWatchdog()
            _isSpeaking.value = false
            _audioLevel.value = 0f
            abandonAudioFocus()
            scheduleAutoResumeListening(400)
        }
    }

    private fun playBackendWav(base64Wav: String, fallbackText: String) {
        try {
            stopSpeaking()
            requestAudioFocus()
            val bytes = Base64.decode(base64Wav, Base64.DEFAULT)
            val tempFile = File.createTempFile("anova_tts_", ".wav", context.cacheDir)
            tempFile.writeBytes(bytes)
            mediaPlayer = MediaPlayer().apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                } else {
                    @Suppress("DEPRECATION")
                    setAudioStreamType(AudioManager.STREAM_MUSIC)
                }
                setDataSource(tempFile.absolutePath)
                setOnPreparedListener { mp ->
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        try {
                            val semitoneRatio = 2.0.pow(voicePitchSemitones / 12.0).toFloat()
                            mp.playbackParams = PlaybackParams().apply {
                                speed = voiceSpeed.coerceIn(0.85f, 1.35f)
                                pitch = semitoneRatio.coerceIn(0.6f, 1.5f)
                            }
                        } catch (_: Exception) {
                            // Some Android 7.1 OEM audio HALs restrict custom pitch; continue normal playback
                        }
                    }
                    _isSpeaking.value = true
                    _audioLevel.value = 0.7f
                    val durMs = (mp.duration.takeIf { it > 0 }?.toLong() ?: 12000L) + 2500L
                    armSpeakWatchdog(durMs) {
                        try {
                            mp.stop()
                            mp.reset()
                            mp.release()
                        } catch (_: Exception) {
                        }
                        mediaPlayer = null
                        tempFile.delete()
                        _isSpeaking.value = false
                        _audioLevel.value = 0f
                        abandonAudioFocus()
                        scheduleAutoResumeListening(350)
                    }
                    mp.start()
                }
                setOnCompletionListener { mp ->
                    cancelSpeakWatchdog()
                    _isSpeaking.value = false
                    _audioLevel.value = 0f
                    try {
                        mp.reset()
                        mp.release()
                    } catch (_: Exception) {
                    }
                    if (mediaPlayer === mp) mediaPlayer = null
                    tempFile.delete()
                    abandonAudioFocus()
                    scheduleAutoResumeListening(300)
                }
                setOnErrorListener { mp, _, _ ->
                    cancelSpeakWatchdog()
                    _isSpeaking.value = false
                    _audioLevel.value = 0f
                    try {
                        mp.reset()
                        mp.release()
                    } catch (_: Exception) {
                    }
                    if (mediaPlayer === mp) mediaPlayer = null
                    tempFile.delete()
                    abandonAudioFocus()
                    if (ttsReady && fallbackText.isNotBlank()) {
                        mainHandler.post { speakViaDeviceTts(fallbackText) }
                    } else {
                        scheduleAutoResumeListening(400)
                    }
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            cancelSpeakWatchdog()
            _isSpeaking.value = false
            abandonAudioFocus()
            if (ttsReady && fallbackText.isNotBlank()) {
                mainHandler.post { speakViaDeviceTts(fallbackText) }
            } else {
                scheduleAutoResumeListening(400)
            }
        }
    }

    fun stopSpeaking() {
        cancelSpeakWatchdog()
        pendingFallbackText = null
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
        mediaPlayer?.let {
            try {
                if (it.isPlaying) it.stop()
                it.reset()
                it.release()
            } catch (_: Exception) {
            }
        }
        mediaPlayer = null
        _isSpeaking.value = false
        _audioLevel.value = 0f
        abandonAudioFocus()
    }

    fun destroy() {
        conversationActive = false
        stopMediaRecorderOnly(discard = true)
        stopSpeaking()
        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }
        try {
            tts?.shutdown()
        } catch (_: Exception) {
        }
    }
}
