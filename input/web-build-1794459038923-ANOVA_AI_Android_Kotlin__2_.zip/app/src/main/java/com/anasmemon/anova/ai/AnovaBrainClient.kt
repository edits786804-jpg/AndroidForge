package com.anasmemon.anova.ai

import android.content.Context
import android.util.Base64
import com.anasmemon.anova.BuildConfig
import com.anasmemon.anova.preferences.AnovaChatEntry
import com.anasmemon.anova.voice.VoiceGender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.ConnectionSpec
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLException

data class AnovaCommandAction(
    val type: String,
    val appName: String = "",
    val query: String = "",
    val contactName: String = "",
    val message: String = "",
    val hour: Int = -1,
    val minute: Int = -1,
    val label: String = "",
    val requiresConfirmation: Boolean = false
)

data class AnovaGroundingSource(
    val title: String,
    val url: String
)

data class AnovaBrainResponse(
    val spokenReply: String,
    val transcript: String? = null,
    val audioBase64Wav: String? = null,
    val action: AnovaCommandAction? = null,
    val sources: List<AnovaGroundingSource> = emptyList(),
    val rememberedFact: String? = null,
    val emptySpeech: Boolean = false,
    val error: String? = null
)

data class BackendDiagnosticReport(
    val ok: Boolean,
    val summary: String
)

class AnovaBrainClient(@Suppress("UNUSED_PARAMETER") context: Context) {
    private val client = OkHttpClient.Builder()
        .connectionSpecs(
            listOf(
                ConnectionSpec.MODERN_TLS,
                ConnectionSpec.COMPATIBLE_TLS
            )
        )
        .followRedirects(false)
        .followSslRedirects(false)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .callTimeout(50, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private fun resolveBaseUrl(overrideUrl: String): String {
        val candidate = overrideUrl.trim().trimEnd('/').ifBlank {
            BuildConfig.ANOVA_BACKEND_URL.trimEnd('/')
        }
        return candidate
    }

    private fun validateHttpsUrl(url: String): String? {
        return if (!url.startsWith("https://", ignoreCase = true)) {
            "Insecure URL blocked. ANOVA AI requires an https:// backend URL."
        } else {
            null
        }
    }

    private fun timezoneOffsetMinutes(): Int {
        return -(TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 60000)
    }

    private fun describeInvalidResponse(code: Int, contentType: String?, body: String, location: String?): String {
        val lowerBody = body.trimStart().lowercase()
        val isHtml = contentType?.contains("text/html", ignoreCase = true) == true ||
            lowerBody.startsWith("<!doctype") ||
            lowerBody.startsWith("<html")

        if (code in 300..399) {
            val redirectTarget = location ?: "login/cookie check"
            return if (redirectTarget.contains("cookie_check") || redirectTarget.contains("aistudio")) {
                "Backend URL requires AI Studio Preview browser login ($code). Deploy the ANOVA backend publicly and set its public URL in Settings."
            } else {
                "Backend URL redirected (HTTP $code to $redirectTarget). Please verify your deployed server URL in Settings."
            }
        }
        if (code == 404) {
            return "Backend endpoint returned HTTP 404 (Not Found). Deploy the ANOVA server or update the Backend URL in Settings."
        }
        if (isHtml) {
            return "Backend returned a web login/HTML page instead of ANOVA JSON API (HTTP $code). Set a public deployed ANOVA backend URL in Settings."
        }
        return "ANOVA backend returned HTTP $code."
    }

    private fun describeNetworkException(e: Exception): String {
        return when (e) {
            is UnknownHostException ->
                "Cannot reach ANOVA server (DNS/host unreachable). Check your internet connection and Backend URL in Settings."
            is ConnectException ->
                "Connection refused by ANOVA server. Verify the server is running and reachable."
            is SocketTimeoutException ->
                "Connection timed out while contacting ANOVA server. Please check your network and try again."
            is SSLException ->
                "Secure HTTPS/TLS handshake failed (${e.message ?: "certificate/TLS error"}). Check device date/time and server SSL certificate."
            else ->
                "Network error contacting ANOVA server: ${e.message ?: "Unknown IO error"}"
        }
    }

    suspend fun testBackendConnection(baseUrl: String): BackendDiagnosticReport = withContext(Dispatchers.IO) {
        val cleanBase = resolveBaseUrl(baseUrl)
        validateHttpsUrl(cleanBase)?.let { err ->
            return@withContext BackendDiagnosticReport(ok = false, summary = err)
        }
        try {
            val healthReq = Request.Builder().url("$cleanBase/api/health").get().build()
            client.newCall(healthReq).execute().use { res ->
                val body = res.body?.string().orEmpty()
                val ct = res.header("Content-Type")
                if (!res.isSuccessful || ct?.contains("application/json", ignoreCase = true) != true) {
                    return@withContext BackendDiagnosticReport(
                        ok = false,
                        summary = describeInvalidResponse(res.code, ct, body, res.header("Location"))
                    )
                }
                val healthJson = JSONObject(body)
                val keyConfigured = healthJson.optBoolean("apiKeyConfigured", false)
                if (!keyConfigured) {
                    return@withContext BackendDiagnosticReport(
                        ok = false,
                        summary = "Backend reachable, but GEMINI_API_KEY is missing on the server."
                    )
                }
            }

            val diagReq = Request.Builder().url("$cleanBase/api/anova/diagnostics").get().build()
            client.newCall(diagReq).execute().use { res ->
                val body = res.body?.string().orEmpty()
                val ct = res.header("Content-Type")
                if (!res.isSuccessful || ct?.contains("application/json", ignoreCase = true) != true) {
                    return@withContext BackendDiagnosticReport(
                        ok = false,
                        summary = describeInvalidResponse(res.code, ct, body, res.header("Location"))
                    )
                }
                val json = JSONObject(body)
                val brainOk = json.optJSONObject("brain")?.optBoolean("ok", false) == true
                val ttsOk = json.optJSONObject("tts")?.optBoolean("ok", false) == true
                val brainMsg = json.optJSONObject("brain")?.optString("message", "") ?: ""
                val ttsMsg = json.optJSONObject("tts")?.optString("message", "") ?: ""
                val overall = brainOk
                val details = buildString {
                    append("Server: OK · Gemini Brain: ")
                    append(if (brainOk) "OK" else brainMsg.ifBlank { "Failed" })
                    append(" · Natural TTS: ")
                    append(if (ttsOk) "OK" else ttsMsg.ifBlank { "Device TTS fallback" })
                }
                return@withContext BackendDiagnosticReport(ok = overall, summary = details)
            }
        } catch (e: Exception) {
            return@withContext BackendDiagnosticReport(
                ok = false,
                summary = describeNetworkException(e)
            )
        }
    }

    suspend fun fetchGreeting(
        baseUrl: String,
        voiceGender: VoiceGender,
        languagePreference: String
    ): Triple<String, String?, String?> = withContext(Dispatchers.IO) {
        val defaultText = "Assalamu Alaikum! Welcome to ANOVA AI, created by Anas Memon. How can I help you today?"
        val cleanBase = resolveBaseUrl(baseUrl)
        validateHttpsUrl(cleanBase)?.let { err ->
            return@withContext Triple(defaultText, null, err)
        }
        val g = if (voiceGender == VoiceGender.MALE) "male" else "female"
        val url = "$cleanBase/api/anova/greeting?voice=$g&lang=$languagePreference"
        try {
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { res ->
                val body = res.body?.string().orEmpty()
                val ct = res.header("Content-Type")
                if (!res.isSuccessful || ct?.contains("application/json", ignoreCase = true) != true) {
                    val issue = describeInvalidResponse(res.code, ct, body, res.header("Location"))
                    return@withContext Triple(defaultText, null, issue)
                }
                val json = JSONObject(body)
                val text = json.optString("text", defaultText)
                val wav = json.optString("audioBase64Wav", "").ifBlank { null }
                val err = json.optString("error", "").ifBlank { null }
                return@withContext Triple(text, wav, err)
            }
        } catch (e: Exception) {
            return@withContext Triple(defaultText, null, describeNetworkException(e))
        }
    }

    suspend fun processVoiceCommand(
        baseUrl: String,
        utterance: String,
        voiceGender: VoiceGender,
        languagePreference: String,
        personality: String,
        memoryEnabled: Boolean,
        memoryFacts: List<String>,
        history: List<AnovaChatEntry>,
        skipTts: Boolean = false
    ): AnovaBrainResponse = withContext(Dispatchers.IO) {
        val cleanBase = resolveBaseUrl(baseUrl)
        val historyArray = JSONArray()
        history.takeLast(10).forEach { entry ->
            historyArray.put(JSONObject().apply {
                put("role", entry.role)
                put("text", entry.text)
            })
        }

        val memoryArray = JSONArray()
        memoryFacts.forEach { memoryArray.put(it) }

        val payload = JSONObject().apply {
            put("utterance", utterance)
            put("voiceGender", if (voiceGender == VoiceGender.MALE) "male" else "female")
            put("languagePreference", languagePreference)
            put("personality", personality)
            put("memoryEnabled", memoryEnabled)
            put("memoryFacts", memoryArray)
            put("history", historyArray)
            put("platform", "android")
            put("timezoneOffsetMinutes", timezoneOffsetMinutes())
            put("skipTts", skipTts)
        }

        executeBrainRequest("$cleanBase/api/anova/command", payload)
    }

    suspend fun processRecordedVoiceTurn(
        baseUrl: String,
        audioBytes: ByteArray,
        mimeType: String,
        voiceGender: VoiceGender,
        languagePreference: String,
        personality: String,
        memoryEnabled: Boolean,
        memoryFacts: List<String>,
        history: List<AnovaChatEntry>
    ): AnovaBrainResponse = withContext(Dispatchers.IO) {
        val cleanBase = resolveBaseUrl(baseUrl)
        val historyArray = JSONArray()
        history.takeLast(10).forEach { entry ->
            historyArray.put(JSONObject().apply {
                put("role", entry.role)
                put("text", entry.text)
            })
        }

        val memoryArray = JSONArray()
        memoryFacts.forEach { memoryArray.put(it) }

        val audioBase64 = Base64.encodeToString(audioBytes, Base64.NO_WRAP)
        val payload = JSONObject().apply {
            put("audioBase64", audioBase64)
            put("mimeType", mimeType)
            put("voiceGender", if (voiceGender == VoiceGender.MALE) "male" else "female")
            put("languagePreference", languagePreference)
            put("personality", personality)
            put("memoryEnabled", memoryEnabled)
            put("memoryFacts", memoryArray)
            put("history", historyArray)
            put("platform", "android")
            put("timezoneOffsetMinutes", timezoneOffsetMinutes())
        }

        executeBrainRequest("$cleanBase/api/anova/voice-turn", payload)
    }

    private fun executeBrainRequest(url: String, payload: JSONObject): AnovaBrainResponse {
        validateHttpsUrl(url)?.let { err ->
            return AnovaBrainResponse(spokenReply = err, error = err)
        }

        var lastException: Exception? = null
        for (attempt in 1..2) {
            try {
                val request = Request.Builder()
                    .url(url)
                    .post(payload.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                client.newCall(request).execute().use { response ->
                    val bodyStr = response.body?.string().orEmpty()
                    val contentType = response.header("Content-Type")
                    val location = response.header("Location")

                    if (!response.isSuccessful) {
                        val serverErr = try {
                            if (contentType?.contains("application/json", ignoreCase = true) == true) {
                                JSONObject(bodyStr).optString("error", "")
                            } else {
                                ""
                            }
                        } catch (_: Exception) {
                            ""
                        }
                        val readable = serverErr.ifBlank {
                            describeInvalidResponse(response.code, contentType, bodyStr, location)
                        }
                        return AnovaBrainResponse(spokenReply = readable, error = readable)
                    }

                    if (contentType?.contains("application/json", ignoreCase = true) != true &&
                        !bodyStr.trimStart().startsWith("{")
                    ) {
                        val readable = describeInvalidResponse(response.code, contentType, bodyStr, location)
                        return AnovaBrainResponse(spokenReply = readable, error = readable)
                    }

                    val json = JSONObject(bodyStr)
                    if (json.optBoolean("empty", false)) {
                        return AnovaBrainResponse(
                            spokenReply = json.optString("notice", ""),
                            emptySpeech = true
                        )
                    }

                    val spokenReply = json.optString("reply", "")
                    val transcript = json.optString("transcript", "").ifBlank { null }
                    val audioBase64 = json.optString("audioBase64Wav", "").ifBlank { null }
                    val rememberedFact = json.optString("rememberedFact", "").ifBlank { null }
                    val actionObj = json.optJSONObject("action")
                    val sourcesArr = json.optJSONArray("sources") ?: JSONArray()

                    val sources = List(sourcesArr.length()) { idx ->
                        val s = sourcesArr.getJSONObject(idx)
                        AnovaGroundingSource(
                            title = s.optString("title", ""),
                            url = s.optString("url", "")
                        )
                    }

                    val action = actionObj?.let {
                        AnovaCommandAction(
                            type = it.optString("type", ""),
                            appName = it.optString("appName", ""),
                            query = it.optString("query", ""),
                            contactName = it.optString("contactName", ""),
                            message = it.optString("message", ""),
                            hour = it.optInt("hour", -1),
                            minute = it.optInt("minute", -1),
                            label = it.optString("label", ""),
                            requiresConfirmation = it.optBoolean("requiresConfirmation", false)
                        )
                    }

                    return AnovaBrainResponse(
                        spokenReply = spokenReply,
                        transcript = transcript,
                        audioBase64Wav = audioBase64,
                        action = action,
                        sources = sources,
                        rememberedFact = rememberedFact
                    )
                }
            } catch (e: IOException) {
                lastException = e
                if (attempt == 1 && e is SocketTimeoutException) continue
                break
            } catch (e: Exception) {
                val msg = "Unexpected response error: ${e.message ?: "Unknown error"}"
                return AnovaBrainResponse(spokenReply = msg, error = msg)
            }
        }

        val errMsg = lastException?.let { describeNetworkException(it) }
            ?: "Could not connect to ANOVA AI server."
        return AnovaBrainResponse(spokenReply = errMsg, error = errMsg)
    }
}
