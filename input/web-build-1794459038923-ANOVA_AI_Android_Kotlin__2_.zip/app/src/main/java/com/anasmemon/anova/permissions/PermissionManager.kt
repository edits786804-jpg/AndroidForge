package com.anasmemon.anova.permissions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

data class PermissionStatusSnapshot(
    val microphoneGranted: Boolean
)

object PermissionManager {
    fun getSnapshot(context: Context): PermissionStatusSnapshot {
        val mic = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        return PermissionStatusSnapshot(
            microphoneGranted = mic
        )
    }
}
