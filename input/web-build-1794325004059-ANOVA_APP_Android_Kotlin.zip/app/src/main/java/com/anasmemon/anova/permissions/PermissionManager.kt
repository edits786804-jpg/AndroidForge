package com.anasmemon.anova.permissions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.anasmemon.anova.accessibility.AnovaAccessibilityService

data class PermissionStatusSnapshot(
    val microphoneGranted: Boolean,
    val contactsGranted: Boolean,
    val notificationsGranted: Boolean,
    val accessibilityEnabled: Boolean
)

object PermissionManager {
    fun getSnapshot(context: Context): PermissionStatusSnapshot {
        val mic = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        val contacts = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED

        val notifications = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        val accessibility = AnovaAccessibilityService.instance != null

        return PermissionStatusSnapshot(
            microphoneGranted = mic,
            contactsGranted = contacts,
            notificationsGranted = notifications,
            accessibilityEnabled = accessibility
        )
    }

    fun openAccessibilitySettings(context: Context) {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
