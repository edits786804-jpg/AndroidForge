package com.anasmemon.anova.ai

import com.anasmemon.anova.BuildConfig
import com.anasmemon.anova.voice.VoiceGender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AnovaCommandAction(
    val type: String, // "open_app", "search_youtube", "call_contact", "whatsapp_message", "set_alarm", "tell_time", "screen_assist"
    val appName: String = "",
    val query: String = "",
    val contactName: String = "",
    val message: String = "",
    val hour: Int = -1,
    val minute: Int = -1,
    val label: String = "",
    val targetText: String = "",
    val inputText: String = "",
    val requiresConfirmation: Boolean = false
)

data class AnovaBrainResponse(
    val spokenReply: String,
    val audioBase64Wav: String? = null,
    val action: AnovaCommandAction? = null,
    val error: String? = null
)

class AnovaBrainClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .build()

    private val history = mutableListOf<Pair<String, String>>()

    suspend fun processVoiceCommand(
        utterance: String,
        voiceGender: VoiceGender,
        accessibilityEnabled: Boolean
    ): AnovaBrainResponse = withContext(Dispatchers.IO) {
        try {
            val historyArray = JSONArray()
            history.takeLast(10).forEach { (role, text) ->
                historyArray.put(JSONObject().apply {
                    put("role", role)
                    put("text", text)
                })
            }

            val payload = JSONObject().apply {
                put("utterance", utterance)
                put("voiceGender", if (voiceGender == VoiceGender.MALE) "male" else "female")
                put("accessibilityEnabled", accessibilityEnabled)
                put("history", historyArray)
                put("platform", "android")
            }

            val request = Request.Builder()
                .url("${BuildConfig.ANOVA_BACKEND_URL}/api/anova/command")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext AnovaBrainResponse(
                        spokenReply = "I could not reach the ANOVA AI server right now. Please check your connection.",
                        error = "HTTP ${response.code}"
                    )
                }

                val json = JSONObject(bodyStr)
                val spokenReply = json.optString("reply", "")
                val audioBase64 = json.optString("audioBase64Wav", "").ifBlank { null }
                val actionObj = json.optJSONObject("action")

                if (spokenReply.isNotBlank()) {
                    history.add("user" to utterance)
                    history.add("model" to spokenReply)
                }

                val action = actionObj?.let {
                    AnovaCommandAction(
                        type = it.optString("type", ""),
                        appName = it.optString("appName", ""),
                        query = it.optString("query", ""),
                        contactName = it.optString("contactName", ""),
                        message = it.optString("message", ""),
                        hour = it.optInt("hour", -1),
                        minute = it.optInt("minute", -1),
                        label = it.optString("label", ""),
                        targetText = it.optString("targetText", ""),
                        inputText = it.optString("inputText", ""),
                        requiresConfirmation = it.optBoolean("requiresConfirmation", false)
                    )
                }

                AnovaBrainResponse(
                    spokenReply = spokenReply,
                    audioBase64Wav = audioBase64,
                    action = action
                )
            }
        } catch (e: Exception) {
            AnovaBrainResponse(
                spokenReply = "Sorry, a network error occurred while thinking. Please try again.",
                error = e.message ?: "Unknown error"
            )
        }
    }
}
