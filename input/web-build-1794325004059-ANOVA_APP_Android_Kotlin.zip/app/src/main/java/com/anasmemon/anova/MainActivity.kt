package com.anasmemon.anova

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.anasmemon.anova.ai.AnovaBrainClient
import com.anasmemon.anova.commands.AndroidCommandExecutor
import com.anasmemon.anova.commands.CommandExecutionResult
import com.anasmemon.anova.commands.PendingConfirmation
import com.anasmemon.anova.permissions.PermissionManager
import com.anasmemon.anova.ui.components.AnovaOrbLogo
import com.anasmemon.anova.ui.components.AnovaOrbState
import com.anasmemon.anova.ui.theme.AnovaTheme
import com.anasmemon.anova.voice.VoiceEngine
import com.anasmemon.anova.voice.VoiceGender
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * ANOVA APP — 100% VOICE ONLY MODE
 * Created and Developed by Anas Memon.
 * Strictly zero text input fields, zero keyboard chat, zero written chat UI.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AnovaRootScreen()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnovaRootScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var darkTheme by remember { mutableStateOf(true) }
    var showSplash by remember { mutableStateOf(true) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var isThinking by remember { mutableStateOf(false) }
    var selectedGender by remember { mutableStateOf(VoiceGender.FEMALE) }
    var statusCaption by remember { mutableStateOf("Tap the orb to speak") }
    var pendingConfirmation by remember { mutableStateOf<PendingConfirmation?>(null) }
    var pendingPermissionRequest by remember { mutableStateOf<Pair<String, String>?>(null) }

    val voiceEngine = remember { VoiceEngine(context) }
    val brainClient = remember { AnovaBrainClient() }
    val commandExecutor = remember { AndroidCommandExecutor(context) }

    val isListening by voiceEngine.isListening.collectAsState()
    val isSpeaking by voiceEngine.isSpeaking.collectAsState()
    val isMuted by voiceEngine.isMuted.collectAsState()
    val audioLevel by voiceEngine.audioLevel.collectAsState()

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            voiceEngine.startListening()
        } else {
            statusCaption = "Microphone access is required for voice control"
        }
    }

    val runtimePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            voiceEngine.speak("Permission granted. Please repeat your command.")
        } else {
            voiceEngine.speak("Permission was denied, so I cannot complete that action.")
        }
        pendingPermissionRequest = null
    }

    LaunchedEffect(Unit) {
        voiceEngine.configureCallbacks(
            onResult = { spokenText ->
                scope.launch {
                    isThinking = true
                    statusCaption = "Thinking..."
                    val snapshot = PermissionManager.getSnapshot(context)
                    val brainResult = brainClient.processVoiceCommand(
                        utterance = spokenText,
                        voiceGender = selectedGender,
                        accessibilityEnabled = snapshot.accessibilityEnabled
                    )
                    isThinking = false

                    val action = brainResult.action
                    if (action != null && action.type.isNotBlank()) {
                        when (val execResult = commandExecutor.handleAction(action)) {
                            is CommandExecutionResult.Executed -> {
                                val speech = brainResult.spokenReply.ifBlank { execResult.spokenFeedback }
                                statusCaption = "Speaking..."
                                voiceEngine.speak(speech, brainResult.audioBase64Wav)
                            }
                            is CommandExecutionResult.NeedsConfirmation -> {
                                pendingConfirmation = execResult.confirmation
                                statusCaption = "Awaiting confirmation"
                                voiceEngine.speak(execResult.confirmation.description)
                            }
                            is CommandExecutionResult.NeedsPermission -> {
                                pendingPermissionRequest = execResult.permission to execResult.explanation
                                statusCaption = "Permission needed"
                                voiceEngine.speak(execResult.explanation)
                            }
                            is CommandExecutionResult.Failed -> {
                                statusCaption = "Ready"
                                voiceEngine.speak(execResult.reason)
                            }
                        }
                    } else {
                        statusCaption = "Speaking..."
                        voiceEngine.speak(brainResult.spokenReply, brainResult.audioBase64Wav)
                    }
                }
            },
            onError = { err ->
                statusCaption = err
                isThinking = false
            }
        )

        delay(2200)
        showSplash = false
        voiceEngine.speak(
            "Assalamu Alaikum! Welcome to ANOVA. I am your personal AI assistant. How can I help you?"
        )
    }

    DisposableEffect(Unit) {
        onDispose { voiceEngine.destroy() }
    }

    val orbState = when {
        isMuted -> AnovaOrbState.MUTED
        isThinking -> AnovaOrbState.THINKING
        isSpeaking -> AnovaOrbState.SPEAKING
        isListening -> AnovaOrbState.LISTENING
        else -> AnovaOrbState.IDLE
    }

    AnovaTheme(darkTheme = darkTheme) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Main Minimal Voice-Only Screen
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Minimal Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ANOVA",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 3.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconButton(onClick = { darkTheme = !darkTheme }) {
                                Icon(
                                    imageVector = if (darkTheme) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                                    contentDescription = "Toggle theme"
                                )
                            }
                            IconButton(onClick = { showSettingsSheet = true }) {
                                Icon(
                                    imageVector = Icons.Rounded.Settings,
                                    contentDescription = "Settings and Permissions"
                                )
                            }
                        }
                    }

                    // Dominant Central 3D Animated Circular Logo
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        AnovaOrbLogo(
                            state = orbState,
                            audioLevel = audioLevel,
                            size = 280.dp,
                            onClick = {
                                if (isListening) {
                                    voiceEngine.stopListening()
                                    statusCaption = "Tap the orb to speak"
                                } else {
                                    val snap = PermissionManager.getSnapshot(context)
                                    if (snap.microphoneGranted) {
                                        voiceEngine.startListening()
                                        statusCaption = "Listening..."
                                    } else {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }
                            }
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Text(
                            text = when (orbState) {
                                AnovaOrbState.LISTENING -> "Listening..."
                                AnovaOrbState.THINKING -> "Thinking..."
                                AnovaOrbState.SPEAKING -> "Speaking..."
                                AnovaOrbState.MUTED -> "Voice Muted"
                                AnovaOrbState.IDLE -> statusCaption
                            },
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }

                    // Voice-Only Control Bar (Mic Activate/Deactivate + Speaker Mute/Unmute)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilledTonalIconButton(
                            onClick = { voiceEngine.setMuted(!isMuted) },
                            modifier = Modifier.size(56.dp)
                        ) {
                            Icon(
                                imageVector = if (isMuted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                                contentDescription = if (isMuted) "Unmute voice" else "Mute voice"
                            )
                        }

                        Button(
                            onClick = {
                                if (isListening) {
                                    voiceEngine.stopListening()
                                    statusCaption = "Microphone paused"
                                } else {
                                    val snap = PermissionManager.getSnapshot(context)
                                    if (snap.microphoneGranted) {
                                        voiceEngine.startListening()
                                        statusCaption = "Listening..."
                                    } else {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }
                            },
                            shape = CircleShape,
                            modifier = Modifier.size(72.dp)
                        ) {
                            Icon(
                                imageVector = if (isListening) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                                contentDescription = if (isListening) "Deactivate microphone" else "Activate microphone",
                                modifier = Modifier.size(30.dp)
                            )
                        }
                    }
                }

                // Splash Screen Overlay
                AnimatedVisibility(
                    visible = showSplash,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0xFF050814), Color(0xFF0B1124))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            AnovaOrbLogo(state = AnovaOrbState.IDLE, size = 210.dp)
                            Spacer(modifier = Modifier.height(28.dp))
                            Text(
                                text = "ANOVA",
                                fontSize = 34.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 8.sp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Created by Anas Memon",
                                fontSize = 14.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            }
        }

        // Settings & Permissions Sheet (Voice-only configuration)
        if (showSettingsSheet) {
            val permissions = PermissionManager.getSnapshot(context)
            ModalBottomSheet(onDismissRequest = { showSettingsSheet = false }) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 12.dp)
                        .navigationBarsPadding(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "ANOVA Settings",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text("Assistant Voice", style = MaterialTheme.typography.labelLarge)
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        SegmentedButton(
                            selected = selectedGender == VoiceGender.FEMALE,
                            onClick = {
                                selectedGender = VoiceGender.FEMALE
                                voiceEngine.setGender(VoiceGender.FEMALE)
                            },
                            shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                        ) { Text("Female") }

                        SegmentedButton(
                            selected = selectedGender == VoiceGender.MALE,
                            onClick = {
                                selectedGender = VoiceGender.MALE
                                voiceEngine.setGender(VoiceGender.MALE)
                            },
                            shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                        ) { Text("Male") }
                    }

                    Text("Permissions & Device Control", style = MaterialTheme.typography.labelLarge)
                    PermissionRow("Microphone (Voice Input)", permissions.microphoneGranted) {
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                    PermissionRow("Contacts (Call & WhatsApp)", permissions.contactsGranted) {
                        runtimePermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        PermissionRow("Notifications", permissions.notificationsGranted) {
                            runtimePermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                    PermissionRow("Screen Assistant (Accessibility)", permissions.accessibilityEnabled) {
                        PermissionManager.openAccessibilitySettings(context)
                    }

                    Text(
                        text = "ANOVA APP · Created and Developed by Anas Memon",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
                    )
                }
            }
        }

        // Sensitive Action Confirmation Dialog
        pendingConfirmation?.let { conf ->
            AlertDialog(
                onDismissRequest = { pendingConfirmation = null },
                title = { Text(conf.title) },
                text = { Text(conf.description) },
                confirmButton = {
                    Button(onClick = {
                        val res = conf.onConfirm()
                        pendingConfirmation = null
                        when (res) {
                            is CommandExecutionResult.Executed -> voiceEngine.speak(res.spokenFeedback)
                            is CommandExecutionResult.Failed -> voiceEngine.speak(res.reason)
                            else -> Unit
                        }
                    }) { Text("Confirm") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        pendingConfirmation = null
                        voiceEngine.speak("Cancelled.")
                    }) { Text("Cancel") }
                }
            )
        }

        // Just-In-Time Permission Explanation Dialog
        pendingPermissionRequest?.let { (perm, explanation) ->
            AlertDialog(
                onDismissRequest = { pendingPermissionRequest = null },
                title = { Text("Permission Required") },
                text = { Text(explanation) },
                confirmButton = {
                    Button(onClick = { runtimePermissionLauncher.launch(perm) }) {
                        Text("Allow")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { pendingPermissionRequest = null }) {
                        Text("Not Now")
                    }
                }
            )
        }
    }
}

@Composable
private fun PermissionRow(
    label: String,
    granted: Boolean,
    onAction: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(label, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                Text(
                    text = if (granted) "Enabled" else "Not enabled",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (!granted) {
                OutlinedButton(onClick = onAction) {
                    Text("Enable")
                }
            }
        }
    }
}
