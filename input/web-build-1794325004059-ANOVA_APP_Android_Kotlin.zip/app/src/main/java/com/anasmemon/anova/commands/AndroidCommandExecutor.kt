package com.anasmemon.anova.commands

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import com.anasmemon.anova.accessibility.AnovaAccessibilityService
import com.anasmemon.anova.ai.AnovaCommandAction
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ResolvedContact(
    val name: String,
    val phoneNumber: String
)

data class PendingConfirmation(
    val title: String,
    val description: String,
    val actionType: String,
    val onConfirm: () -> CommandExecutionResult
)

sealed class CommandExecutionResult {
    data class Executed(val spokenFeedback: String) : CommandExecutionResult()
    data class NeedsConfirmation(val confirmation: PendingConfirmation) : CommandExecutionResult()
    data class NeedsPermission(val permission: String, val explanation: String) : CommandExecutionResult()
    data class Failed(val reason: String) : CommandExecutionResult()
}

class AndroidCommandExecutor(private val context: Context) {

    fun handleAction(action: AnovaCommandAction): CommandExecutionResult {
        return when (action.type) {
            "open_app" -> openApp(action.appName)
            "search_youtube" -> searchYouTube(action.query)
            "tell_time" -> tellTime()
            "set_alarm" -> setAlarm(action.hour, action.minute, action.label)
            "call_contact" -> prepareCall(action.contactName)
            "whatsapp_message" -> prepareWhatsAppMessage(action.contactName, action.message)
            "screen_assist" -> runScreenAssist(action.query, action.targetText, action.inputText)
            else -> CommandExecutionResult.Failed("Unsupported device command: ${action.type}")
        }
    }

    private fun openApp(appName: String): CommandExecutionResult {
        val normalized = appName.trim().lowercase(Locale.ROOT)
        if (normalized.isEmpty()) {
            return CommandExecutionResult.Failed("I did not catch which app to open.")
        }

        val knownPackages = mapOf(
            "whatsapp" to "com.whatsapp",
            "youtube" to "com.google.android.youtube",
            "google" to "com.google.android.googlequicksearchbox",
            "chrome" to "com.android.chrome",
            "camera" to "com.android.camera",
            "settings" to "com.android.settings"
        )

        val pm = context.packageManager
        val directPkg = knownPackages.entries.firstOrNull { normalized.contains(it.key) }?.value

        val launchIntent = if (directPkg != null) {
            pm.getLaunchIntentForPackage(directPkg)
        } else {
            val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val matchedApp = installed.firstOrNull { appInfo ->
                pm.getApplicationLabel(appInfo).toString().lowercase(Locale.ROOT).contains(normalized)
            }
            matchedApp?.let { pm.getLaunchIntentForPackage(it.packageName) }
        }

        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            CommandExecutionResult.Executed("Opening $appName.")
        } else if (normalized.contains("google")) {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(browserIntent)
            CommandExecutionResult.Executed("Opening Google.")
        } else {
            CommandExecutionResult.Failed("$appName is not installed on this device.")
        }
    }

    private fun searchYouTube(query: String): CommandExecutionResult {
        if (query.isBlank()) {
            return CommandExecutionResult.Failed("Please tell me what you want to search on YouTube.")
        }
        val encoded = URLEncoder.encode(query, "UTF-8")
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://www.youtube.com/results?search_query=$encoded")
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            CommandExecutionResult.Executed("Searching YouTube for $query.")
        } catch (e: Exception) {
            CommandExecutionResult.Failed("Could not open YouTube search: ${e.message}")
        }
    }

    private fun tellTime(): CommandExecutionResult {
        val formatter = SimpleDateFormat("h:mm a, EEEE, MMMM d", Locale.getDefault())
        val formatted = formatter.format(Date())
        return CommandExecutionResult.Executed("The current time is $formatted.")
    }

    private fun setAlarm(hour: Int, minute: Int, label: String): CommandExecutionResult {
        if (hour !in 0..23 || minute !in 0..59) {
            return CommandExecutionResult.Failed("Please specify a valid hour and minute for the alarm.")
        }
        val displayTime = String.format(Locale.getDefault(), "%02d:%02d", hour, minute)
        val confirmation = PendingConfirmation(
            title = "Set Alarm",
            description = "Confirm setting an alarm for $displayTime${if (label.isNotBlank()) " ($label)" else ""}?",
            actionType = "set_alarm",
            onConfirm = {
                val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_HOUR, hour)
                    putExtra(AlarmClock.EXTRA_MINUTES, minute)
                    if (label.isNotBlank()) putExtra(AlarmClock.EXTRA_MESSAGE, label)
                    putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    context.startActivity(intent)
                    CommandExecutionResult.Executed("Opening your clock app to confirm the $displayTime alarm.")
                } catch (e: Exception) {
                    CommandExecutionResult.Failed("No alarm app was found on this device to set the alarm.")
                }
            }
        )
        return CommandExecutionResult.NeedsConfirmation(confirmation)
    }

    private fun prepareCall(contactName: String): CommandExecutionResult {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return CommandExecutionResult.NeedsPermission(
                permission = Manifest.permission.READ_CONTACTS,
                explanation = "Contacts permission is needed to find $contactName before opening the phone dialer."
            )
        }

        val contact = findContactByName(contactName)
            ?: return CommandExecutionResult.Failed("I could not find a contact named $contactName in your contacts.")

        return CommandExecutionResult.NeedsConfirmation(
            PendingConfirmation(
                title = "Call ${contact.name}",
                description = "Open the phone dialer to call ${contact.name} (${contact.phoneNumber})?",
                actionType = "call_contact",
                onConfirm = {
                    val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(contact.phoneNumber)}")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        context.startActivity(dialIntent)
                        CommandExecutionResult.Executed("Opening the dialer for ${contact.name}.")
                    } catch (e: Exception) {
                        CommandExecutionResult.Failed("Unable to open the phone dialer: ${e.message}")
                    }
                }
            )
        )
    }

    private fun prepareWhatsAppMessage(contactName: String, message: String): CommandExecutionResult {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return CommandExecutionResult.NeedsPermission(
                permission = Manifest.permission.READ_CONTACTS,
                explanation = "Contacts permission is needed to find $contactName for WhatsApp."
            )
        }

        val contact = findContactByName(contactName)
            ?: return CommandExecutionResult.Failed("I could not find $contactName in your contacts.")

        val sanitizedDigits = contact.phoneNumber.replace(Regex("[^0-9+]"), "")
        if (sanitizedDigits.isBlank()) {
            return CommandExecutionResult.Failed("${contact.name} does not have a valid phone number.")
        }

        return CommandExecutionResult.NeedsConfirmation(
            PendingConfirmation(
                title = "WhatsApp to ${contact.name}",
                description = "Prepare message to ${contact.name} (${contact.phoneNumber}): \"$message\". You will review and send inside WhatsApp.",
                actionType = "whatsapp_message",
                onConfirm = {
                    val encodedMsg = URLEncoder.encode(message, "UTF-8")
                    val cleanNumber = sanitizedDigits.removePrefix("+")
                    val uri = Uri.parse("https://wa.me/$cleanNumber?text=$encodedMsg")
                    val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        context.startActivity(intent)
                        CommandExecutionResult.Executed(
                            "WhatsApp is open with your message ready for ${contact.name}. Please tap Send in WhatsApp to deliver it."
                        )
                    } catch (e: Exception) {
                        CommandExecutionResult.Failed("WhatsApp could not be opened. Please check if WhatsApp is installed.")
                    }
                }
            )
        )
    }

    private fun runScreenAssist(operation: String, targetText: String, inputText: String): CommandExecutionResult {
        val service = AnovaAccessibilityService.instance
            ?: return CommandExecutionResult.Failed(
                "Screen Assistant is not enabled. Please enable ANOVA Screen Assistant in Android Accessibility Settings first."
            )

        return when (operation.lowercase(Locale.ROOT)) {
            "click" -> {
                val ok = service.clickElementByText(targetText)
                if (ok) CommandExecutionResult.Executed("Tapped $targetText on screen.")
                else CommandExecutionResult.Failed("Could not find $targetText on the current screen.")
            }
            "fill" -> {
                CommandExecutionResult.NeedsConfirmation(
                    PendingConfirmation(
                        title = "Confirm Form Input",
                        description = "Type \"$inputText\" into \"$targetText\" on screen?",
                        actionType = "screen_assist_fill",
                        onConfirm = {
                            val filled = service.fillFieldByHintOrFocus(targetText, inputText)
                            if (filled) CommandExecutionResult.Executed("Entered the requested text into $targetText.")
                            else CommandExecutionResult.Failed("Could not find an editable field matching $targetText.")
                        }
                    )
                )
            }
            "scroll" -> {
                val ok = service.scrollForward()
                if (ok) CommandExecutionResult.Executed("Scrolled down.")
                else CommandExecutionResult.Failed("This screen cannot be scrolled further.")
            }
            "back" -> {
                service.navigateBack()
                CommandExecutionResult.Executed("Navigated back.")
            }
            else -> CommandExecutionResult.Failed("Unsupported screen action: $operation")
        }
    }

    private fun findContactByName(nameQuery: String): ResolvedContact? {
        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%${nameQuery.trim()}%"),
            null
        ) ?: return null

        cursor.use {
            if (it.moveToFirst()) {
                val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                if (nameIdx >= 0 && numIdx >= 0) {
                    return ResolvedContact(
                        name = it.getString(nameIdx).orEmpty(),
                        phoneNumber = it.getString(numIdx).orEmpty()
                    )
                }
            }
        }
        return null
    }
}
