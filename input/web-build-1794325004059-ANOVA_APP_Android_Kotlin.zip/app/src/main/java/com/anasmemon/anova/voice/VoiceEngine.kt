package com.anasmemon.anova.voice

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.util.Locale
import java.util.UUID

enum class VoiceGender {
    FEMALE,
    MALE
}

class VoiceEngine(private val context: Context) {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var mediaPlayer: MediaPlayer? = null
    private var ttsReady = false
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted

    private val _audioLevel = MutableStateFlow(0f)
    val audioLevel: StateFlow<Float> = _audioLevel

    var voiceGender: VoiceGender = VoiceGender.FEMALE
    var continuousConversation: Boolean = true

    private var onSpeechRecognized: ((String) -> Unit)? = null
    private var onSpeechError: ((String) -> Unit)? = null

    init {
        initTextToSpeech()
    }

    private fun initTextToSpeech() {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale.getDefault()
                applyVoiceProfile()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                        _audioLevel.value = 0.65f
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                        _audioLevel.value = 0f
                        if (continuousConversation && !_isMuted.value) {
                            mainHandler.postDelayed({ startListeningInternal() }, 350)
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                        _audioLevel.value = 0f
                    }
                })
            }
        }
    }

    private fun applyVoiceProfile() {
        val engine = tts ?: return
        val voices = engine.voices ?: emptySet()
        val desiredFemale = voiceGender == VoiceGender.FEMALE
        val preferred = voices.firstOrNull { voice ->
            val name = voice.name.lowercase(Locale.ROOT)
            val localeMatch = voice.locale.language == Locale.getDefault().language
            if (desiredFemale) {
                localeMatch && (name.contains("female") || name.contains("-f") || name.contains("sfg"))
            } else {
                localeMatch && (name.contains("male") || name.contains("-m") || name.contains("iom"))
            }
        }
        if (preferred != null) {
            engine.voice = preferred
        }
        engine.setPitch(if (desiredFemale) 1.06f else 0.90f)
        engine.setSpeechRate(1.0f)
    }

    fun setGender(gender: VoiceGender) {
        voiceGender = gender
        applyVoiceProfile()
    }

    fun setMuted(muted: Boolean) {
        _isMuted.value = muted
        if (muted) {
            stopSpeaking()
        }
    }

    fun configureCallbacks(
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        this.onSpeechRecognized = onResult
        this.onSpeechError = onError
    }

    fun startListening() {
        mainHandler.post {
            stopSpeaking()
            startListeningInternal()
        }
    }

    private fun startListeningInternal() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onSpeechError?.invoke("Speech recognition service is not available on this device.")
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _isListening.value = true
                }

                override fun onBeginningOfSpeech() {
                    _isListening.value = true
                }

                override fun onRmsChanged(rmsdB: Float) {
                    val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                    _audioLevel.value = normalized
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    _isListening.value = false
                    _audioLevel.value = 0f
                }

                override fun onError(error: Int) {
                    _isListening.value = false
                    _audioLevel.value = 0f
                    val message = when (error) {
                        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            "Network error during speech recognition."
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> ""
                        else -> "Speech recognition error ($error)."
                    }
                    if (message.isNotEmpty()) {
                        onSpeechError?.invoke(message)
                    }
                }

                override fun onResults(results: Bundle?) {
                    _isListening.value = false
                    _audioLevel.value = 0f
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spokenText = matches?.firstOrNull()?.trim().orEmpty()
                    if (spokenText.isNotEmpty()) {
                        onSpeechRecognized?.invoke(spokenText)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            // Automatic multilingual detection support (English, Urdu, Hindi, etc.)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, Locale.getDefault().toLanguageTag())
            putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("en-US", "ur-PK", "hi-IN", "ar-SA"))
        }
        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        mainHandler.post {
            _isListening.value = false
            _audioLevel.value = 0f
            speechRecognizer?.stopListening()
        }
    }

    fun speak(text: String, audioBase64Wav: String? = null) {
        if (_isMuted.value || text.isBlank()) return

        if (!audioBase64Wav.isNullOrBlank()) {
            playBackendWav(audioBase64Wav)
            return
        }

        mainHandler.post {
            if (!ttsReady) return@post
            applyVoiceProfile()
            val utteranceId = UUID.randomUUID().toString()
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        }
    }

    private fun playBackendWav(base64Wav: String) {
        try {
            stopSpeaking()
            val bytes = Base64.decode(base64Wav, Base64.DEFAULT)
            val tempFile = File.createTempFile("anova_tts_", ".wav", context.cacheDir)
            tempFile.writeBytes(bytes)
            mediaPlayer = MediaPlayer().apply {
                setDataSource(tempFile.absolutePath)
                setOnPreparedListener {
                    _isSpeaking.value = true
                    _audioLevel.value = 0.7f
                    start()
                }
                setOnCompletionListener {
                    _isSpeaking.value = false
                    _audioLevel.value = 0f
                    tempFile.delete()
                    if (continuousConversation && !_isMuted.value) {
                        mainHandler.postDelayed({ startListeningInternal() }, 350)
                    }
                }
                setOnErrorListener { _, _, _ ->
                    _isSpeaking.value = false
                    _audioLevel.value = 0f
                    tempFile.delete()
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            _isSpeaking.value = false
        }
    }

    fun stopSpeaking() {
        tts?.stop()
        mediaPlayer?.let {
            if (it.isPlaying) it.stop()
            it.release()
        }
        mediaPlayer = null
        _isSpeaking.value = false
        _audioLevel.value = 0f
    }

    fun destroy() {
        stopSpeaking()
        speechRecognizer?.destroy()
        tts?.shutdown()
    }
}
