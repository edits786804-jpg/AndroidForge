# ANOVA APP — Native Android Build & APK Guide

**Created and Developed by Anas Memon**

## Requirements
- Android Studio Ladybug (2024.2+) or Android SDK Command-line Tools
- JDK 17
- Android SDK Platform 35 (`compileSdk = 35`, `minSdk = 25` for Android 7.1.1+ support)

## 1. Configure Backend URL
In `app/build.gradle.kts`, update `ANOVA_BACKEND_URL` to your deployed ANOVA Express backend URL:
```kotlin
buildConfigField("String", "ANOVA_BACKEND_URL", "\"https://your-deployed-server-url.run.app\"")
```

## 2. Build Debug APK
Open `/android-app` in Android Studio or run from terminal inside `/android-app`:
```bash
gradle assembleDebug
```
Output APK location:
`app/build/outputs/apk/debug/app-debug.apk`

## 3. Install on Android Device via ADB
Enable USB Debugging on your Android phone (Android 7.1.1+):
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## 4. Permissions & Features
- **Microphone (`RECORD_AUDIO`)**: Requested when activating voice listening.
- **Contacts (`READ_CONTACTS`)**: Requested only when calling or preparing WhatsApp messages by contact name.
- **Notifications (`POST_NOTIFICATIONS`)**: Requested on Android 13+.
- **Screen Assistant (`AccessibilityService`)**: Opt-in via Android Settings > Accessibility > ANOVA Screen Assistant. Never monitors or acts without your voice command.
