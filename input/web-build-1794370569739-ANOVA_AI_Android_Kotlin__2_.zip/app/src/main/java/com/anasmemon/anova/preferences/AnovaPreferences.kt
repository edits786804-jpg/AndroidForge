package com.anasmemon.anova.preferences

import android.content.Context
import com.anasmemon.anova.voice.VoiceGender
import org.json.JSONArray
import org.json.JSONObject

data class AnovaChatEntry(
    val role: String,
    val text: String,
    val timestamp: Long
)

data class AnovaUserPrefs(
    val voiceGender: VoiceGender = VoiceGender.FEMALE,
    val languagePreference: String = "auto",
    val personality: String = "balanced",
    val voiceSpeed: Float = 1.0f,
    val voicePitch: Int = 0,
    val autoSpeak: Boolean = true,
    val memoryEnabled: Boolean = false
)

class AnovaPreferencesStore(context: Context) {
    private val prefs = context.getSharedPreferences("anova_ai_prefs_v2", Context.MODE_PRIVATE)

    fun loadPrefs(): AnovaUserPrefs {
        val genderStr = prefs.getString("voiceGender", "female")
        return AnovaUserPrefs(
            voiceGender = if (genderStr == "male") VoiceGender.MALE else VoiceGender.FEMALE,
            languagePreference = prefs.getString("languagePreference", "auto") ?: "auto",
            personality = prefs.getString("personality", "balanced") ?: "balanced",
            voiceSpeed = prefs.getFloat("voiceSpeed", 1.0f).coerceIn(0.75f, 1.35f),
            voicePitch = prefs.getInt("voicePitch", 0).coerceIn(-4, 4),
            autoSpeak = prefs.getBoolean("autoSpeak", true),
            memoryEnabled = prefs.getBoolean("memoryEnabled", false)
        )
    }

    fun savePrefs(p: AnovaUserPrefs) {
        prefs.edit()
            .putString("voiceGender", if (p.voiceGender == VoiceGender.MALE) "male" else "female")
            .putString("languagePreference", p.languagePreference)
            .putString("personality", p.personality)
            .putFloat("voiceSpeed", p.voiceSpeed)
            .putInt("voicePitch", p.voicePitch)
            .putBoolean("autoSpeak", p.autoSpeak)
            .putBoolean("memoryEnabled", p.memoryEnabled)
            .apply()
        if (!p.memoryEnabled) {
            clearMemoryAndHistory()
        }
    }

    fun loadMemoryFacts(): List<String> {
        val raw = prefs.getString("memoryFacts", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { arr.getString(it) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveMemoryFacts(facts: List<String>) {
        val arr = JSONArray()
        facts.takeLast(15).forEach { arr.put(it) }
        prefs.edit().putString("memoryFacts", arr.toString()).apply()
    }

    fun loadChatHistory(): List<AnovaChatEntry> {
        val raw = prefs.getString("chatHistory", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { idx ->
                val obj = arr.getJSONObject(idx)
                AnovaChatEntry(
                    role = obj.optString("role", "model"),
                    text = obj.optString("text", ""),
                    timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveChatHistory(entries: List<AnovaChatEntry>) {
        val arr = JSONArray()
        entries.takeLast(50).forEach { e ->
            arr.put(JSONObject().apply {
                put("role", e.role)
                put("text", e.text)
                put("timestamp", e.timestamp)
            })
        }
        prefs.edit().putString("chatHistory", arr.toString()).apply()
    }

    fun clearMemoryAndHistory() {
        prefs.edit()
            .remove("memoryFacts")
            .remove("chatHistory")
            .apply()
    }
}
