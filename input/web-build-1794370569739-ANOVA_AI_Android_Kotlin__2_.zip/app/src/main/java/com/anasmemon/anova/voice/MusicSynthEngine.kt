package com.anasmemon.anova.voice

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.anasmemon.anova.ai.AnovaSongScore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.sin

/**
 * Polyphonic PCM instrumental synthesizer for Android 7.1+ (API 25+).
 * Renders chords, melody, and bass from Gemini-composed musical scores.
 * Never fakes TextToSpeech as real singing.
 */
class MusicSynthEngine {
    @Volatile
    private var currentTrack: AudioTrack? = null

    private fun midiToFreq(midi: Int): Double =
        440.0 * 2.0.pow((midi - 69) / 12.0)

    suspend fun playScore(score: AnovaSongScore, singerGender: String) = withContext(Dispatchers.Default) {
        stop()
        val sampleRate = 22050
        val bpm = score.bpm.coerceIn(58, 150)
        val stepSamples = ((60.0 / bpm / 2.0) * sampleRate).toInt()
        val totalSteps = 32
        val totalSamples = totalSteps * stepSamples
        val pcm = ShortArray(totalSamples)

        val chords = score.chords.ifEmpty {
            listOf(listOf(60, 64, 67), listOf(55, 59, 62), listOf(57, 60, 64), listOf(53, 57, 60))
        }
        val melody = score.melodyNotes.ifEmpty {
            listOf(72, 74, 76, 74, 72, 71, 69, 67, 72, 74, 76, 79, 76, 74, 72, 72)
        }
        val bass = score.bassNotes.ifEmpty {
            listOf(48, 48, 43, 43, 45, 45, 41, 41)
        }

        val isMale = singerGender == "male"

        for (step in 0 until totalSteps) {
            if (!isActive) return@withContext
            val sMod = step % 16
            val startIdx = step * stepSamples
            val chord = chords[(sMod / 4) % chords.size]
            val bassMidi = bass[(sMod / 2) % bass.size]
            val rawMel = melody[sMod % melody.size]
            val leadMidi = if (rawMel > 0 && isMale) rawMel - 5 else rawMel

            for (n in 0 until stepSamples) {
                val t = n.toDouble() / sampleRate
                val env = (1.0 - n.toDouble() / stepSamples).coerceIn(0.0, 1.0)
                var sample = 0.0

                // Chord pad tones
                for (cm in chord) {
                    sample += sin(2.0 * PI * midiToFreq(cm) * t) * 0.08 * (0.4 + 0.6 * env)
                }
                // Bass tone
                if (bassMidi > 0) {
                    sample += sin(2.0 * PI * midiToFreq(bassMidi) * t) * 0.18 * env
                }
                // Lead melody tone
                if (leadMidi > 0) {
                    sample += sin(2.0 * PI * midiToFreq(leadMidi) * t) * 0.22 * env
                }
                pcm[startIdx + n] = (sample.coerceIn(-0.95, 0.95) * Short.MAX_VALUE).toInt().toShort()
            }
        }

        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, totalSamples * 2))
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        track.write(pcm, 0, pcm.size)
        currentTrack = track
        track.play()
    }

    fun stop() {
        currentTrack?.let { t ->
            try {
                if (t.playState == AudioTrack.PLAYSTATE_PLAYING) t.stop()
                t.release()
            } catch (_: Exception) {}
        }
        currentTrack = null
    }
}
