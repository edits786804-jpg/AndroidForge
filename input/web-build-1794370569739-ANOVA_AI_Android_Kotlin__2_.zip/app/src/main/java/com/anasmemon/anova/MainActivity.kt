package com.anasmemon.anova

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.anasmemon.anova.ai.AnovaBrainClient
import com.anasmemon.anova.ai.AnovaGameState
import com.anasmemon.anova.ai.AnovaSongResult
import com.anasmemon.anova.commands.AndroidCommandExecutor
import com.anasmemon.anova.commands.CommandExecutionResult
import com.anasmemon.anova.commands.PendingConfirmation
import com.anasmemon.anova.permissions.PermissionManager
import com.anasmemon.anova.preferences.AnovaChatEntry
import com.anasmemon.anova.preferences.AnovaPreferencesStore
import com.anasmemon.anova.preferences.AnovaUserPrefs
import com.anasmemon.anova.ui.components.AnovaOrbLogo
import com.anasmemon.anova.ui.components.AnovaOrbState
import com.anasmemon.anova.ui.theme.AnovaTheme
import com.anasmemon.anova.voice.MusicSynthEngine
import com.anasmemon.anova.voice.VoiceEngine
import com.anasmemon.anova.voice.VoiceGender
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * ANOVA AI — Premium Multilingual Voice & Chat Assistant
 * Created and Developed by Anas Memon (ANOVA edits, Tharushah, Sindh, Pakistan).
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AnovaRootScreen()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnovaRootScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val prefsStore = remember { AnovaPreferencesStore(context) }
    val voiceEngine = remember { VoiceEngine(context) }
    val musicEngine = remember { MusicSynthEngine() }
    val brainClient = remember { AnovaBrainClient() }
    val commandExecutor = remember { AndroidCommandExecutor(context) }

    var userPrefs by remember { mutableStateOf(prefsStore.loadPrefs()) }
    var chatHistory by remember {
        mutableStateOf(
            if (userPrefs.memoryEnabled) prefsStore.loadChatHistory() else emptyList()
        )
    }
    var memoryFacts by remember {
        mutableStateOf(
            if (userPrefs.memoryEnabled) prefsStore.loadMemoryFacts() else emptyList()
        )
    }
    var gameState by remember { mutableStateOf<AnovaGameState?>(null) }
    var activeSong by remember { mutableStateOf<AnovaSongResult?>(null) }

    var darkTheme by remember { mutableStateOf(true) }
    var showSplash by remember { mutableStateOf(true) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var showChatSheet by remember { mutableStateOf(false) }
    var showSongDialog by remember { mutableStateOf(false) }
    var isThinking by remember { mutableStateOf(false) }
    var statusCaption by remember { mutableStateOf("Tap the orb to speak") }
    var chatDraft by remember { mutableStateOf("") }
    var songTopicDraft by remember { mutableStateOf("moonlight over Sindh") }
    var songMoodDraft by remember { mutableStateOf("romantic") }
    var songLangDraft by remember { mutableStateOf("Urdu") }
    var pendingConfirmation by remember { mutableStateOf<PendingConfirmation?>(null) }
    var pendingPermissionRequest by remember { mutableStateOf<Pair<String, String>?>(null) }

    val isListening by voiceEngine.isListening.collectAsState()
    val isSpeaking by voiceEngine.isSpeaking.collectAsState()
    val isMuted by voiceEngine.isMuted.collectAsState()
    val audioLevel by voiceEngine.audioLevel.collectAsState()

    fun updateUserPrefs(next: AnovaUserPrefs) {
        userPrefs = next
        prefsStore.savePrefs(next)
        voiceEngine.updateProfile(
            gender = next.voiceGender,
            language = next.languagePreference,
            speed = next.voiceSpeed,
            pitchSemitones = next.voicePitch
        )
        if (!next.memoryEnabled) {
            memoryFacts = emptyList()
        }
    }

    fun appendChat(role: String, text: String) {
        val updated = (chatHistory + AnovaChatEntry(role, text, System.currentTimeMillis())).takeLast(50)
        chatHistory = updated
        if (userPrefs.memoryEnabled) {
            prefsStore.saveChatHistory(updated)
        }
    }

    suspend fun handleUserTurn(utterance: String) {
        if (utterance.isBlank()) return
        appendChat("user", utterance)
        isThinking = true
        statusCaption = "Thinking..."
        val result = brainClient.processVoiceCommand(
            utterance = utterance,
            voiceGender = userPrefs.voiceGender,
            languagePreference = userPrefs.languagePreference,
            personality = userPrefs.personality,
            memoryEnabled = userPrefs.memoryEnabled,
            memoryFacts = memoryFacts,
            gameState = gameState,
            history = chatHistory,
            skipTts = !userPrefs.autoSpeak || isMuted
        )
        isThinking = false

        gameState = result.gameState
        result.rememberedFact?.let { fact ->
            if (userPrefs.memoryEnabled && !memoryFacts.contains(fact)) {
                val updatedFacts = (memoryFacts + fact).takeLast(15)
                memoryFacts = updatedFacts
                prefsStore.saveMemoryFacts(updatedFacts)
            }
        }
        result.songResult?.let { song ->
            activeSong = song
            showSongDialog = true
            song.score?.let { sc ->
                scope.launch { musicEngine.playScore(sc, song.singerGender) }
            }
        }

        val action = result.action
        if (action != null && action.type.isNotBlank()) {
            when (val execResult = commandExecutor.handleAction(action)) {
                is CommandExecutionResult.Executed -> {
                    val speech = result.spokenReply.ifBlank { execResult.spokenFeedback }
                    appendChat("model", speech)
                    statusCaption = "Speaking..."
                    if (userPrefs.autoSpeak && result.songResult == null) {
                        voiceEngine.speak(speech, result.audioBase64Wav)
                    }
                }
                is CommandExecutionResult.NeedsConfirmation -> {
                    pendingConfirmation = execResult.confirmation
                    appendChat("model", execResult.confirmation.description)
                    statusCaption = "Awaiting confirmation"
                    if (userPrefs.autoSpeak) {
                        voiceEngine.speak(execResult.confirmation.description, result.audioBase64Wav)
                    }
                }
                is CommandExecutionResult.Failed -> {
                    appendChat("model", execResult.reason)
                    statusCaption = "Ready"
                    if (userPrefs.autoSpeak) voiceEngine.speak(execResult.reason)
                }
            }
        } else {
            val reply = result.spokenReply.ifBlank { "I am here to help." }
            appendChat("model", reply)
            statusCaption = "Speaking..."
            if (userPrefs.autoSpeak && result.songResult == null) {
                voiceEngine.speak(reply, result.audioBase64Wav)
            } else {
                statusCaption = "Tap the orb to speak"
            }
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            voiceEngine.startListening()
        } else {
            statusCaption = "Microphone access is required for voice control"
        }
    }

    val runtimePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            voiceEngine.speak("Permission granted. Please repeat your command.")
        } else {
            voiceEngine.speak("Permission was denied, so I cannot complete that action.")
        }
        pendingPermissionRequest = null
    }

    LaunchedEffect(Unit) {
        voiceEngine.updateProfile(
            gender = userPrefs.voiceGender,
            language = userPrefs.languagePreference,
            speed = userPrefs.voiceSpeed,
            pitchSemitones = userPrefs.voicePitch
        )
        voiceEngine.configureCallbacks(
            onResult = { spokenText ->
                scope.launch { handleUserTurn(spokenText) }
            },
            onError = { err ->
                statusCaption = err
                isThinking = false
            }
        )

        // Pre-fetch the natural Gemini greeting WAV during the splash animation so first sound is never robotic
        val greetingDeferred = async {
            brainClient.fetchGreeting(userPrefs.voiceGender, userPrefs.languagePreference)
        }
        delay(2000)
        val (greetingText, greetingWav) = greetingDeferred.await()
        showSplash = false
        appendChat("model", greetingText)
        if (userPrefs.autoSpeak) {
            voiceEngine.speak(greetingText, greetingWav)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            voiceEngine.destroy()
            musicEngine.stop()
        }
    }

    val orbState = when {
        isMuted -> AnovaOrbState.MUTED
        isThinking -> AnovaOrbState.THINKING
        isSpeaking -> AnovaOrbState.SPEAKING
        isListening -> AnovaOrbState.LISTENING
        else -> AnovaOrbState.IDLE
    }

    AnovaTheme(darkTheme = darkTheme) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Clean Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ANOVA AI",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 3.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(onClick = { showSongDialog = true }) {
                                Icon(
                                    imageVector = Icons.Rounded.MusicNote,
                                    contentDescription = "Original Song Studio"
                                )
                            }
                            IconButton(onClick = { darkTheme = !darkTheme }) {
                                Icon(
                                    imageVector = if (darkTheme) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                                    contentDescription = "Toggle theme"
                                )
                            }
                            IconButton(onClick = { showSettingsSheet = true }) {
                                Icon(
                                    imageVector = Icons.Rounded.Settings,
                                    contentDescription = "Settings and Preferences"
                                )
                            }
                        }
                    }

                    // Dominant Central 3D Animated Circular Logo
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        AnovaOrbLogo(
                            state = orbState,
                            audioLevel = audioLevel,
                            size = 280.dp,
                            onClick = {
                                if (isSpeaking) {
                                    voiceEngine.stopSpeaking()
                                } else if (isListening) {
                                    voiceEngine.stopListening()
                                    statusCaption = "Tap the orb to speak"
                                } else {
                                    val snap = PermissionManager.getSnapshot(context)
                                    if (snap.microphoneGranted) {
                                        voiceEngine.startListening()
                                        statusCaption = "Listening..."
                                    } else {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }
                            }
                        )

                        Spacer(modifier = Modifier.height(22.dp))

                        Text(
                            text = when (orbState) {
                                AnovaOrbState.LISTENING -> "Listening..."
                                AnovaOrbState.THINKING -> "Thinking..."
                                AnovaOrbState.SPEAKING -> "Speaking..."
                                AnovaOrbState.MUTED -> "Voice Muted"
                                AnovaOrbState.IDLE -> statusCaption
                            },
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )

                        gameState?.let { gs ->
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${gs.activeGame} · Round ${gs.round} · Score ${gs.score}",
                                fontSize = 12.sp,
                                color = Color(0xFF38BDF8)
                            )
                        }
                    }

                    // Clean Bottom Control Bar (Image button beside Mute removed)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilledTonalIconButton(
                            onClick = { voiceEngine.setMuted(!isMuted) },
                            modifier = Modifier.size(56.dp)
                        ) {
                            Icon(
                                imageVector = if (isMuted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                                contentDescription = if (isMuted) "Unmute voice" else "Mute voice"
                            )
                        }

                        Button(
                            onClick = {
                                if (isListening) {
                                    voiceEngine.stopListening()
                                    statusCaption = "Microphone paused"
                                } else {
                                    val snap = PermissionManager.getSnapshot(context)
                                    if (snap.microphoneGranted) {
                                        voiceEngine.startListening()
                                        statusCaption = "Listening..."
                                    } else {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }
                            },
                            shape = CircleShape,
                            modifier = Modifier.size(72.dp)
                        ) {
                            Icon(
                                imageVector = if (isListening) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                                contentDescription = if (isListening) "Deactivate microphone" else "Activate microphone",
                                modifier = Modifier.size(30.dp)
                            )
                        }

                        FilledTonalIconButton(
                            onClick = { showChatSheet = true },
                            modifier = Modifier.size(56.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ChatBubbleOutline,
                                contentDescription = "Open chat history and games"
                            )
                        }
                    }
                }

                // Animated Splash Screen Overlay with Custom 3D Letter A Launcher Icon
                AnimatedVisibility(
                    visible = showSplash,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    val splashTransition = rememberInfiniteTransition(label = "splashPulse")
                    val logoScale by splashTransition.animateFloat(
                        initialValue = 0.96f,
                        targetValue = 1.04f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(durationMillis = 1500),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "logoScale"
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0xFF050814), Color(0xFF0B1124))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Image(
                                painter = painterResource(id = R.drawable.anova_logo_art),
                                contentDescription = "ANOVA AI 3D Letter A Logo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(168.dp)
                                    .scale(logoScale)
                                    .clip(RoundedCornerShape(36.dp))
                            )
                            Spacer(modifier = Modifier.height(28.dp))
                            Text(
                                text = "ANOVA AI",
                                fontSize = 34.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 8.sp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "ANOVA edits · Created by Anas Memon",
                                fontSize = 14.sp,
                                color = Color(0xFFCBD5E1)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Tharushah, Sindh, Pakistan",
                                fontSize = 12.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            }
        }

        // Chat & Games History Sheet
        if (showChatSheet) {
            ModalBottomSheet(onDismissRequest = { showChatSheet = false }) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 560.dp)
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .navigationBarsPadding()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Chat & Games",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (chatHistory.isNotEmpty()) {
                            IconButton(onClick = {
                                chatHistory = emptyList()
                                gameState = null
                                prefsStore.saveChatHistory(emptyList())
                            }) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Clear history")
                            }
                        }
                    }

                    LazyColumn(
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(chatHistory) { item ->
                            val isUser = item.role == "user"
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isUser) Color(0xFF2563EB) else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = item.text,
                                    color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface,
                                    fontSize = 14.sp,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp, bottom = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = chatDraft,
                            onValueChange = { chatDraft = it },
                            placeholder = { Text("Type message, riddle, or quiz...") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                val text = chatDraft.trim()
                                if (text.isNotEmpty()) {
                                    chatDraft = ""
                                    scope.launch { handleUserTurn(text) }
                                }
                            }
                        ) {
                            Icon(Icons.Rounded.Send, contentDescription = "Send")
                        }
                    }
                }
            }
        }

        // Original Song Studio Dialog
        if (showSongDialog) {
            AlertDialog(
                onDismissRequest = {
                    musicEngine.stop()
                    showSongDialog = false
                },
                title = { Text("Original Song Studio") },
                text = {
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = songTopicDraft,
                            onValueChange = { songTopicDraft = it },
                            label = { Text("Song Topic") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Urdu", "Hindi", "English").forEach { l ->
                                FilterChip(
                                    selected = songLangDraft == l,
                                    onClick = { songLangDraft = l },
                                    label = { Text(l) }
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("romantic", "motivational", "sad").forEach { m ->
                                FilterChip(
                                    selected = songMoodDraft == m,
                                    onClick = { songMoodDraft = m },
                                    label = { Text(m) }
                                )
                            }
                        }
                        activeSong?.let { s ->
                            Text(s.title, fontWeight = FontWeight.SemiBold)
                            s.notice?.let { n ->
                                Text(n, fontSize = 11.sp, color = Color(0xFFF59E0B))
                            }
                            Text(s.lyrics, fontSize = 13.sp)
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        scope.launch {
                            val generated = brainClient.generateSong(
                                topic = songTopicDraft,
                                mood = songMoodDraft,
                                language = songLangDraft,
                                singerGender = userPrefs.voiceGender
                            )
                            activeSong = generated
                            generated?.score?.let { sc ->
                                musicEngine.playScore(sc, generated.singerGender)
                            }
                        }
                    }) { Text("Compose & Play") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        musicEngine.stop()
                        showSongDialog = false
                    }) { Text("Close") }
                }
            )
        }

        // Full Settings & Preferences Sheet
        if (showSettingsSheet) {
            val permissions = PermissionManager.getSnapshot(context)
            ModalBottomSheet(onDismissRequest = { showSettingsSheet = false }) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 24.dp, vertical = 12.dp)
                        .navigationBarsPadding(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "ANOVA AI Settings",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text("Natural Assistant Voice", style = MaterialTheme.typography.labelLarge)
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        SegmentedButton(
                            selected = userPrefs.voiceGender == VoiceGender.FEMALE,
                            onClick = { updateUserPrefs(userPrefs.copy(voiceGender = VoiceGender.FEMALE)) },
                            shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                        ) { Text("Female") }

                        SegmentedButton(
                            selected = userPrefs.voiceGender == VoiceGender.MALE,
                            onClick = { updateUserPrefs(userPrefs.copy(voiceGender = VoiceGender.MALE)) },
                            shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                        ) { Text("Male") }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Auto-Speak Replies (TTS)", fontSize = 14.sp)
                        Switch(
                            checked = userPrefs.autoSpeak,
                            onCheckedChange = { updateUserPrefs(userPrefs.copy(autoSpeak = it)) }
                        )
                    }

                    Text(
                        "Voice Speed: ${String.format("%.2fx", userPrefs.voiceSpeed)}",
                        fontSize = 13.sp
                    )
                    Slider(
                        value = userPrefs.voiceSpeed,
                        onValueChange = { updateUserPrefs(userPrefs.copy(voiceSpeed = it)) },
                        valueRange = 0.75f..1.35f
                    )

                    Text(
                        "Voice Pitch: ${userPrefs.voicePitch} semitones",
                        fontSize = 13.sp
                    )
                    Slider(
                        value = userPrefs.voicePitch.toFloat(),
                        onValueChange = {
                            updateUserPrefs(userPrefs.copy(voicePitch = it.roundToInt()))
                        },
                        valueRange = -4f..4f,
                        steps = 7
                    )

                    Text("Language Mode", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("auto" to "Auto", "en" to "EN", "ur" to "Urdu", "hi" to "Hindi", "sd" to "Sindhi")
                            .forEach { (id, label) ->
                                FilterChip(
                                    selected = userPrefs.languagePreference == id,
                                    onClick = { updateUserPrefs(userPrefs.copy(languagePreference = id)) },
                                    label = { Text(label) }
                                )
                            }
                    }

                    Text("Personality Mode", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("balanced" to "Warm", "playful" to "Fun", "teacher" to "Teacher", "professional" to "Pro")
                            .forEach { (id, label) ->
                                FilterChip(
                                    selected = userPrefs.personality == id,
                                    onClick = { updateUserPrefs(userPrefs.copy(personality = id)) },
                                    label = { Text(label) }
                                )
                            }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Conversation Memory", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text(
                                "With permission, saves preferences locally",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = userPrefs.memoryEnabled,
                            onCheckedChange = { updateUserPrefs(userPrefs.copy(memoryEnabled = it)) }
                        )
                    }

                    Text("Permissions", style = MaterialTheme.typography.labelLarge)
                    PermissionRow("Microphone (Voice Input)", permissions.microphoneGranted) {
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        PermissionRow("Notifications", permissions.notificationsGranted) {
                            runtimePermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }

                    Text(
                        text = "ANOVA AI · ANOVA edits\nCreated by Anas Memon · Tharushah, Sindh, Pakistan",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
                    )
                }
            }
        }

        // Sensitive Action Confirmation Dialog
        pendingConfirmation?.let { conf ->
            AlertDialog(
                onDismissRequest = { pendingConfirmation = null },
                title = { Text(conf.title) },
                text = { Text(conf.description) },
                confirmButton = {
                    Button(onClick = {
                        val res = conf.onConfirm()
                        pendingConfirmation = null
                        when (res) {
                            is CommandExecutionResult.Executed -> voiceEngine.speak(res.spokenFeedback)
                            is CommandExecutionResult.Failed -> voiceEngine.speak(res.reason)
                            else -> Unit
                        }
                    }) { Text("Confirm") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        pendingConfirmation = null
                        voiceEngine.speak("Cancelled.")
                    }) { Text("Cancel") }
                }
            )
        }

        // Just-In-Time Permission Explanation Dialog
        pendingPermissionRequest?.let { (perm, explanation) ->
            AlertDialog(
                onDismissRequest = { pendingPermissionRequest = null },
                title = { Text("Permission Required") },
                text = { Text(explanation) },
                confirmButton = {
                    Button(onClick = { runtimePermissionLauncher.launch(perm) }) {
                        Text("Allow")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { pendingPermissionRequest = null }) {
                        Text("Not Now")
                    }
                }
            )
        }
    }
}

@Composable
private fun PermissionRow(
    label: String,
    granted: Boolean,
    onAction: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(label, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                Text(
                    text = if (granted) "Enabled" else "Not enabled",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (!granted) {
                OutlinedButton(onClick = onAction) {
                    Text("Enable")
                }
            }
        }
    }
}
