package com.anasmemon.anova.ai

import com.anasmemon.anova.BuildConfig
import com.anasmemon.anova.preferences.AnovaChatEntry
import com.anasmemon.anova.voice.VoiceGender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class AnovaCommandAction(
    val type: String,
    val appName: String = "",
    val query: String = "",
    val contactName: String = "",
    val message: String = "",
    val hour: Int = -1,
    val minute: Int = -1,
    val label: String = "",
    val requiresConfirmation: Boolean = false
)

data class AnovaGameState(
    val activeGame: String,
    val round: Int,
    val score: Int,
    val detail: String
)

data class AnovaGroundingSource(
    val title: String,
    val url: String
)

data class AnovaSongScore(
    val bpm: Int,
    val key: String,
    val mood: String,
    val chords: List<List<Int>>,
    val melodyNotes: List<Int>,
    val bassNotes: List<Int>
)

data class AnovaSongResult(
    val mode: String,
    val requiresPaidKeyForVocals: Boolean,
    val notice: String?,
    val title: String,
    val language: String,
    val mood: String,
    val singerGender: String,
    val lyrics: String,
    val score: AnovaSongScore?
)

data class AnovaBrainResponse(
    val spokenReply: String,
    val audioBase64Wav: String? = null,
    val action: AnovaCommandAction? = null,
    val gameState: AnovaGameState? = null,
    val sources: List<AnovaGroundingSource> = emptyList(),
    val songResult: AnovaSongResult? = null,
    val rememberedFact: String? = null,
    val error: String? = null
)

class AnovaBrainClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    suspend fun fetchGreeting(
        voiceGender: VoiceGender,
        languagePreference: String
    ): Pair<String, String?> = withContext(Dispatchers.IO) {
        val g = if (voiceGender == VoiceGender.MALE) "male" else "female"
        val url = "${BuildConfig.ANOVA_BACKEND_URL}/api/anova/greeting?voice=$g&lang=$languagePreference"
        try {
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { res ->
                val json = JSONObject(res.body?.string().orEmpty())
                val text = json.optString(
                    "text",
                    "Assalamu Alaikum! Welcome to ANOVA AI, created by Anas Memon. How can I help you today?"
                )
                val wav = json.optString("audioBase64Wav", "").ifBlank { null }
                return@withContext text to wav
            }
        } catch (_: Exception) {
            return@withContext (
                "Assalamu Alaikum! Welcome to ANOVA AI, created by Anas Memon. How can I help you today?" to null
            )
        }
    }

    suspend fun generateSong(
        topic: String,
        mood: String,
        language: String,
        singerGender: VoiceGender
    ): AnovaSongResult? = withContext(Dispatchers.IO) {
        val payload = JSONObject().apply {
            put("topic", topic)
            put("mood", mood)
            put("language", language)
            put("singerGender", if (singerGender == VoiceGender.MALE) "male" else "female")
        }
        try {
            val req = Request.Builder()
                .url("${BuildConfig.ANOVA_BACKEND_URL}/api/anova/song")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()
            client.newCall(req).execute().use { res ->
                if (!res.isSuccessful) return@withContext null
                parseSong(JSONObject(res.body?.string().orEmpty()))
            }
        } catch (_: Exception) {
            null
        }
    }

    suspend fun processVoiceCommand(
        utterance: String,
        voiceGender: VoiceGender,
        languagePreference: String,
        personality: String,
        memoryEnabled: Boolean,
        memoryFacts: List<String>,
        gameState: AnovaGameState?,
        history: List<AnovaChatEntry>,
        skipTts: Boolean = false
    ): AnovaBrainResponse = withContext(Dispatchers.IO) {
        val historyArray = JSONArray()
        history.takeLast(10).forEach { entry ->
            historyArray.put(JSONObject().apply {
                put("role", entry.role)
                put("text", entry.text)
            })
        }

        val memoryArray = JSONArray()
        memoryFacts.forEach { memoryArray.put(it) }

        val payload = JSONObject().apply {
            put("utterance", utterance)
            put("voiceGender", if (voiceGender == VoiceGender.MALE) "male" else "female")
            put("languagePreference", languagePreference)
            put("personality", personality)
            put("memoryEnabled", memoryEnabled)
            put("memoryFacts", memoryArray)
            put("history", historyArray)
            put("platform", "android")
            put("skipTts", skipTts)
            if (gameState != null) {
                put("gameState", JSONObject().apply {
                    put("activeGame", gameState.activeGame)
                    put("round", gameState.round)
                    put("score", gameState.score)
                    put("detail", gameState.detail)
                })
            }
        }

        executeBrainRequest("${BuildConfig.ANOVA_BACKEND_URL}/api/anova/command", payload)
    }

    private fun parseSong(obj: JSONObject): AnovaSongResult {
        val scoreObj = obj.optJSONObject("score")
        val score = scoreObj?.let { s ->
            val chordsArr = s.optJSONArray("chords") ?: JSONArray()
            val chords = List(chordsArr.length()) { ci ->
                val inner = chordsArr.getJSONArray(ci)
                List(inner.length()) { ni -> inner.getInt(ni) }
            }
            val melArr = s.optJSONArray("melodyNotes") ?: JSONArray()
            val mel = List(melArr.length()) { melArr.getInt(it) }
            val bassArr = s.optJSONArray("bassNotes") ?: JSONArray()
            val bass = List(bassArr.length()) { bassArr.getInt(it) }
            AnovaSongScore(
                bpm = s.optInt("bpm", 90),
                key = s.optString("key", "C Major"),
                mood = s.optString("mood", "motivational"),
                chords = chords,
                melodyNotes = mel,
                bassNotes = bass
            )
        }
        return AnovaSongResult(
            mode = obj.optString("mode", "free-instrumental-synth"),
            requiresPaidKeyForVocals = obj.optBoolean("requiresPaidKeyForVocals", true),
            notice = obj.optString("notice", "").ifBlank { null },
            title = obj.optString("title", "Original Song"),
            language = obj.optString("language", "English"),
            mood = obj.optString("mood", "motivational"),
            singerGender = obj.optString("singerGender", "female"),
            lyrics = obj.optString("lyrics", ""),
            score = score
        )
    }

    private fun executeBrainRequest(url: String, payload: JSONObject): AnovaBrainResponse {
        var lastException: Exception? = null
        for (attempt in 1..2) {
            try {
                val request = Request.Builder()
                    .url(url)
                    .post(payload.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                client.newCall(request).execute().use { response ->
                    val bodyStr = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        val serverErr = try {
                            JSONObject(bodyStr).optString("error", "")
                        } catch (_: Exception) {
                            ""
                        }
                        val readable = serverErr.ifBlank { "ANOVA backend returned HTTP ${response.code}." }
                        return AnovaBrainResponse(spokenReply = readable, error = readable)
                    }

                    val json = JSONObject(bodyStr)
                    val spokenReply = json.optString("reply", "")
                    val audioBase64 = json.optString("audioBase64Wav", "").ifBlank { null }
                    val rememberedFact = json.optString("rememberedFact", "").ifBlank { null }
                    val actionObj = json.optJSONObject("action")
                    val gameObj = json.optJSONObject("gameState")
                    val songObj = json.optJSONObject("songResult")
                    val sourcesArr = json.optJSONArray("sources") ?: JSONArray()

                    val sources = List(sourcesArr.length()) { idx ->
                        val s = sourcesArr.getJSONObject(idx)
                        AnovaGroundingSource(
                            title = s.optString("title", ""),
                            url = s.optString("url", "")
                        )
                    }

                    val action = actionObj?.let {
                        AnovaCommandAction(
                            type = it.optString("type", ""),
                            appName = it.optString("appName", ""),
                            query = it.optString("query", ""),
                            contactName = it.optString("contactName", ""),
                            message = it.optString("message", ""),
                            hour = it.optInt("hour", -1),
                            minute = it.optInt("minute", -1),
                            label = it.optString("label", ""),
                            requiresConfirmation = it.optBoolean("requiresConfirmation", false)
                        )
                    }

                    val nextGame = gameObj?.let {
                        val gName = it.optString("activeGame", "")
                        if (gName.isBlank()) null
                        else AnovaGameState(
                            activeGame = gName,
                            round = it.optInt("round", 1),
                            score = it.optInt("score", 0),
                            detail = it.optString("detail", "")
                        )
                    }

                    return AnovaBrainResponse(
                        spokenReply = spokenReply,
                        audioBase64Wav = audioBase64,
                        action = action,
                        gameState = nextGame,
                        sources = sources,
                        songResult = songObj?.let { parseSong(it) },
                        rememberedFact = rememberedFact
                    )
                }
            } catch (e: IOException) {
                lastException = e
                if (attempt == 1) continue
            } catch (e: Exception) {
                return AnovaBrainResponse(
                    spokenReply = "An error occurred: ${e.message ?: "Unknown error"}",
                    error = e.message ?: "Unknown error"
                )
            }
        }

        return AnovaBrainResponse(
            spokenReply = "I could not connect to the ANOVA AI server. Please check your internet connection.",
            error = lastException?.message ?: "Network timeout"
        )
    }
}
