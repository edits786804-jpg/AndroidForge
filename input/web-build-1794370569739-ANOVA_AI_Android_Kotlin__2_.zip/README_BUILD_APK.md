# ANOVA AI — Security Hardening & Signed APK Build Guide

**Brand:** ANOVA edits  
**Creator:** Anas Memon (Tharushah, Sindh, Pakistan)

## 1. Security & Google Play Protect Audit Fixes Applied
1. **Removed `BIND_ACCESSIBILITY_SERVICE` & Window Content Reading**: `AnovaAccessibilityService` (`canRetrieveWindowContent`, `canPerformGestures`, `ACTION_SET_TEXT`) was removed because combining Accessibility screen injection with internet access is the primary heuristic trigger for Google Play Protect malware flags on side-loaded APKs.
2. **Removed Unnecessary Dangerous Permissions**: Removed `CALL_PHONE` (phone calls safely use `Intent.ACTION_DIAL`) and `READ_CONTACTS` (WhatsApp and Dialer launch safely via user-confirmed intents without reading the contacts database). Only `INTERNET`, `RECORD_AUDIO`, `SET_ALARM`, and optional `POST_NOTIFICATIONS` remain.
3. **Enforced TLS/HTTPS Only**: Added `res/xml/network_security_config.xml` (`cleartextTrafficPermitted="false"`) and `android:usesCleartextTraffic="false"`.
4. **Disabled Backup & Data Extraction**: Configured `android:allowBackup="false"`, `android:fullBackupContent="false"`, and `res/xml/data_extraction_rules.xml`.
5. **Custom Launcher Icon**: Replaced the system placeholder icon with custom 3D letter "A" mipmap icons (`mipmap-mdpi` through `mipmap-xxxhdpi` + `mipmap-anydpi-v26` adaptive icons) so the app presents verified ANOVA AI branding.
6. **Note on Play Protect**: Never attempt to disable or bypass Google Play Protect. Side-loaded APKs signed with a new personal keystore may still show an "Unknown developer / Unrecognized app" Play Protect prompt until scanned by Play Protect or distributed via Google Play Console.

## 2. Generate a Real Release Signing Keystore
Run once inside `/android-app`:
```bash
keytool -genkeypair -v \
  -keystore anova-release.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias anova_release
```
Copy `keystore.properties.example` to `keystore.properties` and enter your keystore passwords.

## 3. Build a Properly Signed Release APK (Android 7.1.1+ / API 25+)
```bash
./gradlew clean assembleRelease
```
Signed APK output:
`app/build/outputs/apk/release/app-release.apk`

Verify v2/v3 APK signature using Android SDK `apksigner`:
```bash
apksigner verify --verbose app/build/outputs/apk/release/app-release.apk
```

## 4. Install & Test on Android 7.1.1+
```bash
adb install -r app/build/outputs/apk/release/app-release.apk
```
