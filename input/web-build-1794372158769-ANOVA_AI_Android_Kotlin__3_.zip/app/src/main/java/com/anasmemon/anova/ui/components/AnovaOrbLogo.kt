package com.anasmemon.anova.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.anasmemon.anova.ui.theme.AnovaBlue
import com.anasmemon.anova.ui.theme.AnovaCyan
import com.anasmemon.anova.ui.theme.AnovaPurple
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class AnovaOrbState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    MUTED
}

private data class OrbitParticle(
    val angleOffset: Float,
    val radiusFactor: Float,
    val speedFactor: Float,
    val sizeDp: Float,
    val color: Color
)

@Composable
fun AnovaOrbLogo(
    state: AnovaOrbState,
    audioLevel: Float = 0f,
    size: Dp = 260.dp,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "anovaOrb")

    val primaryRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    AnovaOrbState.THINKING -> 2600
                    AnovaOrbState.LISTENING -> 5000
                    AnovaOrbState.SPEAKING -> 4200
                    else -> 11000
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "primaryRotation"
    )

    val counterRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    AnovaOrbState.THINKING -> 3400
                    AnovaOrbState.SPEAKING -> 5600
                    else -> 14000
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "counterRotation"
    )

    val breath by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breath"
    )

    val levelBoost by animateFloatAsState(
        targetValue = audioLevel.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 90),
        label = "audioLevel"
    )

    val particles = remember {
        List(28) { i ->
            val palette = listOf(AnovaCyan, AnovaBlue, AnovaPurple)
            OrbitParticle(
                angleOffset = (i * 137.5f) % 360f,
                radiusFactor = 0.72f + (i % 5) * 0.06f,
                speedFactor = if (i % 2 == 0) 1f else -0.8f,
                sizeDp = 1.8f + (i % 3) * 1.1f,
                color = palette[i % palette.size]
            )
        }
    }

    val interactionSource = remember { MutableInteractionSource() }
    val clickableModifier = if (onClick != null) {
        modifier.clickable(
            interactionSource = interactionSource,
            indication = null,
            onClick = onClick
        )
    } else {
        modifier
    }

    Canvas(
        modifier = clickableModifier.size(size)
    ) {
        val center = Offset(this.size.width / 2f, this.size.height / 2f)
        val baseRadius = (this.size.minDimension / 2f) * 0.54f
        val dynamicScale = when (state) {
            AnovaOrbState.LISTENING -> 1f + levelBoost * 0.16f
            AnovaOrbState.SPEAKING -> 1f + levelBoost * 0.22f
            AnovaOrbState.THINKING -> breath * 1.03f
            AnovaOrbState.MUTED -> 0.92f
            AnovaOrbState.IDLE -> breath
        }
        val coreRadius = baseRadius * dynamicScale

        // Outer ambient cosmic halo
        val haloAlpha = when (state) {
            AnovaOrbState.LISTENING -> 0.42f + levelBoost * 0.25f
            AnovaOrbState.SPEAKING -> 0.48f + levelBoost * 0.30f
            AnovaOrbState.THINKING -> 0.45f
            AnovaOrbState.MUTED -> 0.14f
            AnovaOrbState.IDLE -> 0.28f
        }

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    AnovaCyan.copy(alpha = haloAlpha),
                    AnovaPurple.copy(alpha = haloAlpha * 0.55f),
                    Color.Transparent
                ),
                center = center,
                radius = coreRadius * 1.95f
            ),
            radius = coreRadius * 1.95f,
            center = center
        )

        // Outer animated orbital rings (3D tilted illusion)
        val ringColors = listOf(AnovaCyan, AnovaBlue, AnovaPurple)
        for (ringIndex in 0..2) {
            val ringRadius = coreRadius * (1.22f + ringIndex * 0.17f)
            val tiltY = 0.64f + ringIndex * 0.13f
            val angle = if (ringIndex % 2 == 0) {
                primaryRotation + ringIndex * 42f
            } else {
                counterRotation - ringIndex * 35f
            }

            rotate(degrees = angle, pivot = center) {
                drawOval(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            ringColors[ringIndex].copy(alpha = 0.08f),
                            ringColors[ringIndex].copy(alpha = if (state == AnovaOrbState.MUTED) 0.25f else 0.90f),
                            ringColors[(ringIndex + 1) % 3].copy(alpha = 0.55f),
                            ringColors[ringIndex].copy(alpha = 0.08f)
                        ),
                        center = center
                    ),
                    topLeft = Offset(center.x - ringRadius, center.y - ringRadius * tiltY),
                    size = Size(ringRadius * 2f, ringRadius * 2f * tiltY),
                    style = Stroke(width = (2.4f - ringIndex * 0.4f).dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }

        // Orbiting glowing particles
        particles.forEach { p ->
            val rad = ((p.angleOffset + primaryRotation * p.speedFactor) * PI / 180.0).toFloat()
            val px = center.x + cos(rad) * (this.size.minDimension * 0.44f * p.radiusFactor)
            val py = center.y + sin(rad) * (this.size.minDimension * 0.44f * p.radiusFactor)
            drawCircle(
                color = p.color.copy(alpha = if (state == AnovaOrbState.MUTED) 0.25f else 0.85f),
                radius = p.sizeDp.dp.toPx(),
                center = Offset(px, py)
            )
        }

        // 3D Spherical Core
        drawCircle(
            brush = Brush.radialGradient(
                colors = when (state) {
                    AnovaOrbState.THINKING -> listOf(
                        Color(0xFFE0E7FF),
                        AnovaPurple,
                        Color(0xFF1E1B4B)
                    )
                    AnovaOrbState.LISTENING -> listOf(
                        Color(0xFFE0F2FE),
                        AnovaCyan,
                        Color(0xFF0F172A)
                    )
                    AnovaOrbState.SPEAKING -> listOf(
                        Color(0xFFECFEFF),
                        AnovaBlue,
                        Color(0xFF172554)
                    )
                    AnovaOrbState.MUTED -> listOf(
                        Color(0xFF64748B),
                        Color(0xFF334155),
                        Color(0xFF0F172A)
                    )
                    AnovaOrbState.IDLE -> listOf(
                        Color(0xFFDbeAFE),
                        AnovaBlue,
                        AnovaPurple.copy(alpha = 0.9f),
                        Color(0xFF0B1124)
                    )
                },
                center = Offset(center.x - coreRadius * 0.28f, center.y - coreRadius * 0.28f),
                radius = coreRadius * 1.25f
            ),
            radius = coreRadius,
            center = center
        )

        // Inner specular rim highlight for futuristic glass/3D depth
        drawCircle(
            brush = Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.55f),
                    AnovaCyan.copy(alpha = 0.25f),
                    Color.Transparent
                )
            ),
            radius = coreRadius * 0.96f,
            center = center,
            style = Stroke(width = 1.6.dp.toPx())
        )
    }
}
