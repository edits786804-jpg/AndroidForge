package com.anasmemon.anova

import android.app.Application

class AnovaApp : Application()
