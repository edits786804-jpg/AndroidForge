package com.anasmemon.anova.commands

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import com.anasmemon.anova.ai.AnovaCommandAction
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class PendingConfirmation(
    val title: String,
    val description: String,
    val actionType: String,
    val onConfirm: () -> CommandExecutionResult
)

sealed class CommandExecutionResult {
    data class Executed(val spokenFeedback: String) : CommandExecutionResult()
    data class NeedsConfirmation(val confirmation: PendingConfirmation) : CommandExecutionResult()
    data class Failed(val reason: String) : CommandExecutionResult()
}

class AndroidCommandExecutor(private val context: Context) {

    fun handleAction(action: AnovaCommandAction): CommandExecutionResult {
        return when (action.type) {
            "open_app" -> openApp(action.appName)
            "search_youtube" -> searchYouTube(action.query)
            "tell_time" -> tellTime()
            "set_alarm" -> setAlarm(action.hour, action.minute, action.label)
            "call_contact" -> prepareDialer(action.contactName)
            "whatsapp_message" -> prepareWhatsAppMessage(action.contactName, action.message)
            else -> CommandExecutionResult.Failed("Unsupported device command: ${action.type}")
        }
    }

    private fun openApp(appName: String): CommandExecutionResult {
        val normalized = appName.trim().lowercase(Locale.ROOT)
        if (normalized.isEmpty()) {
            return CommandExecutionResult.Failed("I did not catch which app to open.")
        }

        val url = when {
            normalized.contains("youtube") -> "https://www.youtube.com"
            normalized.contains("whatsapp") -> "https://wa.me/"
            normalized.contains("google") -> "https://www.google.com"
            else -> null
        }

        return if (url != null) {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(intent)
                CommandExecutionResult.Executed("Opening $appName.")
            } catch (e: Exception) {
                CommandExecutionResult.Failed("Could not open $appName: ${e.message}")
            }
        } else {
            CommandExecutionResult.Failed("Opening $appName is not available directly.")
        }
    }

    private fun searchYouTube(query: String): CommandExecutionResult {
        if (query.isBlank()) {
            return CommandExecutionResult.Failed("Please tell me what you want to search on YouTube.")
        }
        val encoded = URLEncoder.encode(query, "UTF-8")
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://www.youtube.com/results?search_query=$encoded")
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            CommandExecutionResult.Executed("Searching YouTube for $query.")
        } catch (e: Exception) {
            CommandExecutionResult.Failed("Could not open YouTube search: ${e.message}")
        }
    }

    private fun tellTime(): CommandExecutionResult {
        val formatter = SimpleDateFormat("h:mm a, EEEE, MMMM d", Locale.getDefault())
        val formatted = formatter.format(Date())
        return CommandExecutionResult.Executed("The current time is $formatted.")
    }

    private fun setAlarm(hour: Int, minute: Int, label: String): CommandExecutionResult {
        if (hour !in 0..23 || minute !in 0..59) {
            return CommandExecutionResult.Failed("Please specify a valid hour and minute for the alarm.")
        }
        val displayTime = String.format(Locale.getDefault(), "%02d:%02d", hour, minute)
        return CommandExecutionResult.NeedsConfirmation(
            PendingConfirmation(
                title = "Set Alarm",
                description = "Confirm opening your clock app to set an alarm for $displayTime${if (label.isNotBlank()) " ($label)" else ""}?",
                actionType = "set_alarm",
                onConfirm = {
                    val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                        putExtra(AlarmClock.EXTRA_HOUR, hour)
                        putExtra(AlarmClock.EXTRA_MINUTES, minute)
                        if (label.isNotBlank()) putExtra(AlarmClock.EXTRA_MESSAGE, label)
                        putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        context.startActivity(intent)
                        CommandExecutionResult.Executed("Opening your clock app to confirm the $displayTime alarm.")
                    } catch (e: Exception) {
                        CommandExecutionResult.Failed("No alarm app was found on this device to set the alarm.")
                    }
                }
            )
        )
    }

    private fun prepareDialer(contactName: String): CommandExecutionResult {
        val digits = contactName.filter { it.isDigit() || it == '+' }
        val telUri = if (digits.length >= 3) Uri.parse("tel:${Uri.encode(digits)}") else Uri.parse("tel:")
        return CommandExecutionResult.NeedsConfirmation(
            PendingConfirmation(
                title = "Open Phone Dialer",
                description = if (digits.length >= 3) {
                    "Open the phone dialer for $digits? You will place the call manually."
                } else {
                    "Open the phone dialer so you can select $contactName and place the call?"
                },
                actionType = "call_contact",
                onConfirm = {
                    val dialIntent = Intent(Intent.ACTION_DIAL, telUri).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        context.startActivity(dialIntent)
                        CommandExecutionResult.Executed("Opening your phone dialer.")
                    } catch (e: Exception) {
                        CommandExecutionResult.Failed("Unable to open the phone dialer: ${e.message}")
                    }
                }
            )
        )
    }

    private fun prepareWhatsAppMessage(contactName: String, message: String): CommandExecutionResult {
        val encodedMsg = URLEncoder.encode(message, "UTF-8")
        val digits = contactName.filter { it.isDigit() }
        val waUrl = if (digits.length >= 7) {
            "https://wa.me/$digits?text=$encodedMsg"
        } else {
            "https://wa.me/?text=$encodedMsg"
        }

        return CommandExecutionResult.NeedsConfirmation(
            PendingConfirmation(
                title = "Prepare WhatsApp Message",
                description = "Open WhatsApp with message \"$message\"? You will select the recipient and tap Send inside WhatsApp.",
                actionType = "whatsapp_message",
                onConfirm = {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(waUrl)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        context.startActivity(intent)
                        CommandExecutionResult.Executed(
                            "WhatsApp is open with your message ready. Please select the recipient and tap Send inside WhatsApp."
                        )
                    } catch (e: Exception) {
                        CommandExecutionResult.Failed("WhatsApp could not be opened on this device.")
                    }
                }
            )
        )
    }
}
