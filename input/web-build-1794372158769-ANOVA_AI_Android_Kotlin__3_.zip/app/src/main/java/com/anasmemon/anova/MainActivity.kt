package com.anasmemon.anova

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.anasmemon.anova.ai.AnovaBrainClient
import com.anasmemon.anova.ai.AnovaBrainResponse
import com.anasmemon.anova.commands.AndroidCommandExecutor
import com.anasmemon.anova.commands.CommandExecutionResult
import com.anasmemon.anova.commands.PendingConfirmation
import com.anasmemon.anova.permissions.PermissionManager
import com.anasmemon.anova.preferences.AnovaChatEntry
import com.anasmemon.anova.preferences.AnovaPreferencesStore
import com.anasmemon.anova.preferences.AnovaUserPrefs
import com.anasmemon.anova.ui.components.AnovaOrbLogo
import com.anasmemon.anova.ui.components.AnovaOrbState
import com.anasmemon.anova.ui.theme.AnovaTheme
import com.anasmemon.anova.voice.VoiceEngine
import com.anasmemon.anova.voice.VoiceGender
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

/**
 * ANOVA AI — Multilingual Voice & Chat Assistant
 * Created and Developed by Anas Memon (ANOVA edits, Tharushah, Sindh, Pakistan).
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AnovaRootScreen()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnovaRootScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val prefsStore = remember { AnovaPreferencesStore(context) }
    val voiceEngine = remember { VoiceEngine(context) }
    val brainClient = remember { AnovaBrainClient(context) }
    val commandExecutor = remember { AndroidCommandExecutor(context) }

    var userPrefs by remember { mutableStateOf(prefsStore.loadPrefs()) }
    var backendUrlDraft by remember { mutableStateOf(userPrefs.backendUrl) }
    var diagStatus by remember { mutableStateOf<String?>(null) }
    var isTestingConnection by remember { mutableStateOf(false) }

    var chatHistory by remember {
        mutableStateOf(
            if (userPrefs.memoryEnabled) prefsStore.loadChatHistory() else emptyList()
        )
    }
    var memoryFacts by remember {
        mutableStateOf(
            if (userPrefs.memoryEnabled) prefsStore.loadMemoryFacts() else emptyList()
        )
    }

    var darkTheme by remember { mutableStateOf(true) }
    var showSplash by remember { mutableStateOf(true) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var showChatSheet by remember { mutableStateOf(false) }
    var isThinking by remember { mutableStateOf(false) }
    var statusCaption by remember { mutableStateOf("Tap the orb to speak") }
    var chatDraft by remember { mutableStateOf("") }
    var pendingConfirmation by remember { mutableStateOf<PendingConfirmation?>(null) }
    var pendingPermissionRequest by remember { mutableStateOf<Pair<String, String>?>(null) }

    val isListening by voiceEngine.isListening.collectAsState()
    val isSpeaking by voiceEngine.isSpeaking.collectAsState()
    val isMuted by voiceEngine.isMuted.collectAsState()
    val audioLevel by voiceEngine.audioLevel.collectAsState()

    fun updateUserPrefs(next: AnovaUserPrefs) {
        userPrefs = next
        prefsStore.savePrefs(next)
        voiceEngine.updateProfile(
            gender = next.voiceGender,
            language = next.languagePreference,
            speed = next.voiceSpeed,
            pitchSemitones = next.voicePitch
        )
        if (!next.memoryEnabled) {
            memoryFacts = emptyList()
        }
    }

    fun appendChat(role: String, text: String) {
        val updated = (chatHistory + AnovaChatEntry(role, text, System.currentTimeMillis())).takeLast(50)
        chatHistory = updated
        if (userPrefs.memoryEnabled) {
            prefsStore.saveChatHistory(updated)
        }
    }

    fun handleBrainResponse(result: AnovaBrainResponse) {
        if (result.emptySpeech) {
            statusCaption = "Tap the orb to speak"
            return
        }

        result.transcript?.let { spokenTranscript ->
            appendChat("user", spokenTranscript)
        }

        result.rememberedFact?.let { fact ->
            if (userPrefs.memoryEnabled && !memoryFacts.contains(fact)) {
                val updatedFacts = (memoryFacts + fact).takeLast(15)
                memoryFacts = updatedFacts
                prefsStore.saveMemoryFacts(updatedFacts)
            }
        }

        if (result.error != null) {
            val readableErr = result.spokenReply.ifBlank { result.error }
            appendChat("model", readableErr)
            statusCaption = readableErr
            if (userPrefs.autoSpeak && !isMuted) {
                voiceEngine.speak(readableErr)
            }
            return
        }

        val action = result.action
        if (action != null && action.type.isNotBlank()) {
            when (val execResult = commandExecutor.handleAction(action)) {
                is CommandExecutionResult.Executed -> {
                    val speech = result.spokenReply.ifBlank { execResult.spokenFeedback }
                    appendChat("model", speech)
                    statusCaption = if (userPrefs.autoSpeak && !isMuted) "Speaking..." else "Tap the orb to speak"
                    if (userPrefs.autoSpeak && !isMuted) {
                        voiceEngine.speak(speech, result.audioBase64Wav)
                    }
                }
                is CommandExecutionResult.NeedsConfirmation -> {
                    pendingConfirmation = execResult.confirmation
                    appendChat("model", execResult.confirmation.description)
                    statusCaption = "Awaiting confirmation"
                    if (userPrefs.autoSpeak && !isMuted) {
                        voiceEngine.speak(execResult.confirmation.description, result.audioBase64Wav)
                    }
                }
                is CommandExecutionResult.Failed -> {
                    appendChat("model", execResult.reason)
                    statusCaption = execResult.reason
                    if (userPrefs.autoSpeak && !isMuted) voiceEngine.speak(execResult.reason)
                }
            }
        } else {
            val reply = result.spokenReply.ifBlank { "I am here to help." }
            appendChat("model", reply)
            statusCaption = if (userPrefs.autoSpeak && !isMuted) "Speaking..." else "Tap the orb to speak"
            if (userPrefs.autoSpeak && !isMuted) {
                voiceEngine.speak(reply, result.audioBase64Wav)
            }
        }
    }

    suspend fun handleUserTurn(utterance: String) {
        if (utterance.isBlank()) return
        appendChat("user", utterance)
        isThinking = true
        statusCaption = "Thinking..."
        val result = brainClient.processVoiceCommand(
            baseUrl = userPrefs.backendUrl,
            utterance = utterance,
            voiceGender = userPrefs.voiceGender,
            languagePreference = userPrefs.languagePreference,
            personality = userPrefs.personality,
            memoryEnabled = userPrefs.memoryEnabled,
            memoryFacts = memoryFacts,
            history = chatHistory,
            skipTts = !userPrefs.autoSpeak || isMuted
        )
        isThinking = false
        handleBrainResponse(result)
    }

    suspend fun handleRecordedVoiceTurn(audioBytes: ByteArray, mimeType: String) {
        isThinking = true
        statusCaption = "Thinking..."
        val result = brainClient.processRecordedVoiceTurn(
            baseUrl = userPrefs.backendUrl,
            audioBytes = audioBytes,
            mimeType = mimeType,
            voiceGender = userPrefs.voiceGender,
            languagePreference = userPrefs.languagePreference,
            personality = userPrefs.personality,
            memoryEnabled = userPrefs.memoryEnabled,
            memoryFacts = memoryFacts,
            history = chatHistory
        )
        isThinking = false
        handleBrainResponse(result)
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            voiceEngine.startListening()
            statusCaption = "Listening..."
        } else {
            statusCaption = "Microphone access is required for voice control"
        }
    }

    val runtimePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            voiceEngine.speak("Permission granted. Please repeat your command.")
        } else {
            voiceEngine.speak("Permission was denied, so I cannot complete that action.")
        }
        pendingPermissionRequest = null
    }

    LaunchedEffect(Unit) {
        voiceEngine.updateProfile(
            gender = userPrefs.voiceGender,
            language = userPrefs.languagePreference,
            speed = userPrefs.voiceSpeed,
            pitchSemitones = userPrefs.voicePitch
        )
        voiceEngine.configureCallbacks(
            onResult = { spokenText ->
                scope.launch { handleUserTurn(spokenText) }
            },
            onAudioCaptured = { bytes, mime ->
                scope.launch { handleRecordedVoiceTurn(bytes, mime) }
            },
            onError = { err ->
                statusCaption = err
                isThinking = false
            }
        )

        val greetingDeferred = async {
            brainClient.fetchGreeting(
                userPrefs.backendUrl,
                userPrefs.voiceGender,
                userPrefs.languagePreference
            )
        }
        delay(2000)
        val (greetingText, greetingWav, greetingErr) = greetingDeferred.await()
        showSplash = false
        appendChat("model", greetingText)
        if (greetingErr != null) {
            statusCaption = greetingErr
        }
        if (userPrefs.autoSpeak && !isMuted) {
            voiceEngine.speak(greetingText, greetingWav)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            voiceEngine.destroy()
        }
    }

    val orbState = when {
        isMuted -> AnovaOrbState.MUTED
        isThinking -> AnovaOrbState.THINKING
        isSpeaking -> AnovaOrbState.SPEAKING
        isListening -> AnovaOrbState.LISTENING
        else -> AnovaOrbState.IDLE
    }

    AnovaTheme(darkTheme = darkTheme) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Clean Header with Clearly Visible Settings Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ANOVA AI",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 3.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { darkTheme = !darkTheme }) {
                                Icon(
                                    imageVector = if (darkTheme) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                                    contentDescription = "Toggle theme"
                                )
                            }
                            FilledTonalButton(
                                onClick = { showSettingsSheet = true },
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Settings,
                                    contentDescription = "Settings",
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Settings", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }

                    // Dominant Central 3D Animated Circular Logo
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        AnovaOrbLogo(
                            state = orbState,
                            audioLevel = audioLevel,
                            size = 280.dp,
                            onClick = {
                                if (isSpeaking) {
                                    voiceEngine.stopSpeaking()
                                    if (!isListening) {
                                        val snap = PermissionManager.getSnapshot(context)
                                        if (snap.microphoneGranted) {
                                            voiceEngine.startListening()
                                            statusCaption = "Listening..."
                                        }
                                    }
                                } else if (isListening) {
                                    voiceEngine.stopListening()
                                    statusCaption = "Tap the orb to speak"
                                } else {
                                    val snap = PermissionManager.getSnapshot(context)
                                    if (snap.microphoneGranted) {
                                        voiceEngine.startListening()
                                        statusCaption = "Listening..."
                                    } else {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }
                            }
                        )

                        Spacer(modifier = Modifier.height(22.dp))

                        Text(
                            text = when (orbState) {
                                AnovaOrbState.LISTENING -> "Listening..."
                                AnovaOrbState.THINKING -> "Thinking..."
                                AnovaOrbState.SPEAKING -> "Speaking..."
                                AnovaOrbState.MUTED -> "Voice Muted"
                                AnovaOrbState.IDLE -> statusCaption
                            },
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }

                    // Clean Bottom Control Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilledTonalIconButton(
                            onClick = { voiceEngine.setMuted(!isMuted) },
                            modifier = Modifier.size(56.dp)
                        ) {
                            Icon(
                                imageVector = if (isMuted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                                contentDescription = if (isMuted) "Unmute voice" else "Mute voice"
                            )
                        }

                        Button(
                            onClick = {
                                if (isListening) {
                                    voiceEngine.stopListening()
                                    statusCaption = "Microphone paused"
                                } else {
                                    val snap = PermissionManager.getSnapshot(context)
                                    if (snap.microphoneGranted) {
                                        voiceEngine.startListening()
                                        statusCaption = "Listening..."
                                    } else {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }
                            },
                            shape = CircleShape,
                            modifier = Modifier.size(72.dp)
                        ) {
                            Icon(
                                imageVector = if (isListening) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                                contentDescription = if (isListening) "Deactivate microphone" else "Activate microphone",
                                modifier = Modifier.size(30.dp)
                            )
                        }

                        FilledTonalIconButton(
                            onClick = { showChatSheet = true },
                            modifier = Modifier.size(56.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ChatBubbleOutline,
                                contentDescription = "Open chat conversation"
                            )
                        }
                    }
                }

                // Animated Splash Screen Overlay with Custom 3D Letter A Launcher Icon
                AnimatedVisibility(
                    visible = showSplash,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    val splashTransition = rememberInfiniteTransition(label = "splashPulse")
                    val logoScale by splashTransition.animateFloat(
                        initialValue = 0.96f,
                        targetValue = 1.04f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(durationMillis = 1500),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "logoScale"
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0xFF050814), Color(0xFF0B1124))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Image(
                                painter = painterResource(id = R.drawable.anova_logo_art),
                                contentDescription = "ANOVA AI 3D Letter A Logo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(168.dp)
                                    .scale(logoScale)
                                    .clip(RoundedCornerShape(36.dp))
                            )
                            Spacer(modifier = Modifier.height(28.dp))
                            Text(
                                text = "ANOVA AI",
                                fontSize = 34.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 8.sp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "ANOVA edits · Created by Anas Memon",
                                fontSize = 14.sp,
                                color = Color(0xFFCBD5E1)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Tharushah, Sindh, Pakistan",
                                fontSize = 12.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            }
        }

        // Chat Conversation Sheet
        if (showChatSheet) {
            ModalBottomSheet(onDismissRequest = { showChatSheet = false }) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 560.dp)
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .navigationBarsPadding()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Conversation",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (chatHistory.isNotEmpty()) {
                            IconButton(onClick = {
                                chatHistory = emptyList()
                                prefsStore.saveChatHistory(emptyList())
                            }) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Clear history")
                            }
                        }
                    }

                    LazyColumn(
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(chatHistory) { item ->
                            val isUser = item.role == "user"
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isUser) Color(0xFF2563EB) else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = item.text,
                                    color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface,
                                    fontSize = 14.sp,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp, bottom = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = chatDraft,
                            onValueChange = { chatDraft = it },
                            placeholder = { Text("Message ANOVA AI...") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                val text = chatDraft.trim()
                                if (text.isNotEmpty()) {
                                    chatDraft = ""
                                    scope.launch { handleUserTurn(text) }
                                }
                            }
                        ) {
                            Icon(Icons.Rounded.Send, contentDescription = "Send")
                        }
                    }
                }
            }
        }

        // Full Settings & Backend Connection Sheet
        if (showSettingsSheet) {
            val permissions = PermissionManager.getSnapshot(context)
            ModalBottomSheet(onDismissRequest = { showSettingsSheet = false }) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 24.dp, vertical = 12.dp)
                        .navigationBarsPadding(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "ANOVA AI Settings",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text("Natural Assistant Voice", style = MaterialTheme.typography.labelLarge)
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        SegmentedButton(
                            selected = userPrefs.voiceGender == VoiceGender.FEMALE,
                            onClick = { updateUserPrefs(userPrefs.copy(voiceGender = VoiceGender.FEMALE)) },
                            shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                        ) { Text("Female") }

                        SegmentedButton(
                            selected = userPrefs.voiceGender == VoiceGender.MALE,
                            onClick = { updateUserPrefs(userPrefs.copy(voiceGender = VoiceGender.MALE)) },
                            shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                        ) { Text("Male") }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Auto-Speak Replies (TTS)", fontSize = 14.sp)
                        Switch(
                            checked = userPrefs.autoSpeak,
                            onCheckedChange = { updateUserPrefs(userPrefs.copy(autoSpeak = it)) }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Dark Theme", fontSize = 14.sp)
                        Switch(
                            checked = darkTheme,
                            onCheckedChange = { darkTheme = it }
                        )
                    }

                    Text(
                        "Speech Speed: ${String.format(Locale.US, "%.2fx", userPrefs.voiceSpeed)}",
                        fontSize = 13.sp
                    )
                    Slider(
                        value = userPrefs.voiceSpeed,
                        onValueChange = { updateUserPrefs(userPrefs.copy(voiceSpeed = it)) },
                        valueRange = 0.85f..1.35f
                    )

                    Text(
                        "Voice Pitch: ${userPrefs.voicePitch} semitones",
                        fontSize = 13.sp
                    )
                    Slider(
                        value = userPrefs.voicePitch.toFloat(),
                        onValueChange = {
                            updateUserPrefs(userPrefs.copy(voicePitch = it.roundToInt()))
                        },
                        valueRange = -4f..4f,
                        steps = 7
                    )

                    Text("Language Mode", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("auto" to "Auto", "en" to "EN", "ur" to "Urdu", "hi" to "Hindi", "sd" to "Sindhi")
                            .forEach { (id, label) ->
                                FilterChip(
                                    selected = userPrefs.languagePreference == id,
                                    onClick = { updateUserPrefs(userPrefs.copy(languagePreference = id)) },
                                    label = { Text(label) }
                                )
                            }
                    }

                    Text("Assistant Tone", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("balanced" to "Warm", "teacher" to "Teacher", "professional" to "Pro")
                            .forEach { (id, label) ->
                                FilterChip(
                                    selected = userPrefs.personality == id,
                                    onClick = { updateUserPrefs(userPrefs.copy(personality = id)) },
                                    label = { Text(label) }
                                )
                            }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Conversation Memory", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text(
                                "With permission, saves preferences locally",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = userPrefs.memoryEnabled,
                            onCheckedChange = { updateUserPrefs(userPrefs.copy(memoryEnabled = it)) }
                        )
                    }

                    // Backend Server Connectivity & Diagnostics (no API key stored in APK)
                    Text("Backend Server Connection", style = MaterialTheme.typography.labelLarge)
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "Gemini API keys stay safely on your ANOVA backend server. Point the APK to your publicly deployed backend URL.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedTextField(
                                value = backendUrlDraft,
                                onValueChange = { backendUrlDraft = it },
                                label = { Text("Backend URL") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        val savedUrl = prefsStore.normalizeBackendUrl(backendUrlDraft)
                                        backendUrlDraft = savedUrl
                                        updateUserPrefs(userPrefs.copy(backendUrl = savedUrl))
                                        diagStatus = "Saved Backend URL: $savedUrl"
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Save URL", fontSize = 12.sp)
                                }
                                OutlinedButton(
                                    onClick = {
                                        val defUrl = BuildConfig.ANOVA_BACKEND_URL.trimEnd('/')
                                        backendUrlDraft = defUrl
                                        updateUserPrefs(userPrefs.copy(backendUrl = defUrl))
                                        diagStatus = "Reset to default URL."
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Reset", fontSize = 12.sp)
                                }
                            }
                            Button(
                                onClick = {
                                    val targetUrl = prefsStore.normalizeBackendUrl(backendUrlDraft)
                                    backendUrlDraft = targetUrl
                                    updateUserPrefs(userPrefs.copy(backendUrl = targetUrl))
                                    isTestingConnection = true
                                    diagStatus = "Testing connection..."
                                    scope.launch {
                                        val report = brainClient.testBackendConnection(targetUrl)
                                        diagStatus = report.summary
                                        isTestingConnection = false
                                    }
                                },
                                enabled = !isTestingConnection,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    if (isTestingConnection) "Testing..." else "Test Backend & Gemini Connection",
                                    fontSize = 12.sp
                                )
                            }
                            diagStatus?.let { statusText ->
                                Text(
                                    text = statusText,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Text("Permissions", style = MaterialTheme.typography.labelLarge)
                    PermissionRow("Microphone (Voice Input)", permissions.microphoneGranted) {
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        PermissionRow("Notifications", permissions.notificationsGranted) {
                            runtimePermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }

                    Text(
                        text = "ANOVA AI · ANOVA edits\nCreated by Anas Memon · Tharushah, Sindh, Pakistan",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
                    )
                }
            }
        }

        // Sensitive Action Confirmation Dialog
        pendingConfirmation?.let { conf ->
            AlertDialog(
                onDismissRequest = { pendingConfirmation = null },
                title = { Text(conf.title) },
                text = { Text(conf.description) },
                confirmButton = {
                    Button(onClick = {
                        val res = conf.onConfirm()
                        pendingConfirmation = null
                        when (res) {
                            is CommandExecutionResult.Executed -> voiceEngine.speak(res.spokenFeedback)
                            is CommandExecutionResult.Failed -> voiceEngine.speak(res.reason)
                            else -> Unit
                        }
                    }) { Text("Confirm") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        pendingConfirmation = null
                        voiceEngine.speak("Cancelled.")
                    }) { Text("Cancel") }
                }
            )
        }

        // Just-In-Time Permission Explanation Dialog
        pendingPermissionRequest?.let { (perm, explanation) ->
            AlertDialog(
                onDismissRequest = { pendingPermissionRequest = null },
                title = { Text("Permission Required") },
                text = { Text(explanation) },
                confirmButton = {
                    Button(onClick = { runtimePermissionLauncher.launch(perm) }) {
                        Text("Allow")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { pendingPermissionRequest = null }) {
                        Text("Not Now")
                    }
                }
            )
        }
    }
}

@Composable
private fun PermissionRow(
    label: String,
    granted: Boolean,
    onAction: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(label, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                Text(
                    text = if (granted) "Enabled" else "Not enabled",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (!granted) {
                OutlinedButton(onClick = onAction) {
                    Text("Enable")
                }
            }
        }
    }
}
