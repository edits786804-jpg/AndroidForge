package com.anasmemon.anova.voice

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.PlaybackParams
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.util.Locale
import java.util.UUID
import kotlin.math.pow

enum class VoiceGender {
    FEMALE,
    MALE
}

class VoiceEngine(private val context: Context) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private var speechRecognizer: SpeechRecognizer? = null
    private var mediaRecorder: MediaRecorder? = null
    private var recorderFile: File? = null
    private var isRecordingFallback = false
    private var useDirectAudioFallback = false
    private var recognizerClientErrors = 0

    private var tts: TextToSpeech? = null
    private var mediaPlayer: MediaPlayer? = null
    private var ttsReady = false
    private var pendingFallbackText: String? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var audioFocusRequest: AudioFocusRequest? = null

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted

    private val _audioLevel = MutableStateFlow(0f)
    val audioLevel: StateFlow<Float> = _audioLevel

    var voiceGender: VoiceGender = VoiceGender.FEMALE
    var languagePreference: String = "auto"
    var voiceSpeed: Float = 1.08f
    var voicePitchSemitones: Int = 0
    var continuousConversation: Boolean = true
    var conversationActive: Boolean = false

    private var onSpeechRecognized: ((String) -> Unit)? = null
    private var onAudioCaptured: ((ByteArray, String) -> Unit)? = null
    private var onSpeechError: ((String) -> Unit)? = null

    private val focusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
            stopSpeaking()
        }
    }

    init {
        initTextToSpeech()
    }

    @Suppress("DEPRECATION")
    private fun requestAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = audioFocusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setOnAudioFocusChangeListener(focusChangeListener)
                .build()
                .also { audioFocusRequest = it }
            am.requestAudioFocus(req)
        } else {
            am.requestAudioFocus(
                focusChangeListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
        } else {
            am.abandonAudioFocus(focusChangeListener)
        }
    }

    private fun initTextToSpeech() {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                applyVoiceProfile()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                        _audioLevel.value = 0.65f
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                        _audioLevel.value = 0f
                        abandonAudioFocus()
                        scheduleAutoResumeListening(320)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                        _audioLevel.value = 0f
                        abandonAudioFocus()
                        scheduleAutoResumeListening(420)
                    }
                })
                pendingFallbackText?.let { queued ->
                    pendingFallbackText = null
                    speakViaDeviceTts(queued)
                }
            }
        }
    }

    private fun scheduleAutoResumeListening(delayMs: Long) {
        if (continuousConversation && conversationActive && !_isMuted.value) {
            mainHandler.postDelayed({
                if (conversationActive && !_isMuted.value && !_isSpeaking.value && !_isListening.value) {
                    startListeningInternal()
                }
            }, delayMs)
        }
    }

    private fun resolveTargetLocale(): Locale {
        return when (languagePreference) {
            "ur" -> Locale("ur", "PK")
            "hi" -> Locale("hi", "IN")
            "sd" -> Locale("sd", "PK")
            "en" -> Locale.US
            else -> Locale.getDefault()
        }
    }

    private fun applyVoiceProfile() {
        val engine = tts ?: return
        val desiredLocale = resolveTargetLocale()
        val langStatus = try {
            engine.setLanguage(desiredLocale)
        } catch (_: Exception) {
            TextToSpeech.LANG_NOT_SUPPORTED
        }

        // Android 7.1 OEM TTS engines often lack Urdu/Sindhi packs; safely fall back so speech stays audible
        val activeLocale = if (
            langStatus == TextToSpeech.LANG_MISSING_DATA ||
            langStatus == TextToSpeech.LANG_NOT_SUPPORTED
        ) {
            val fallbackLocale = if (desiredLocale.language == "ur" || desiredLocale.language == "sd") {
                val hiStatus = engine.setLanguage(Locale("hi", "IN"))
                if (hiStatus >= TextToSpeech.LANG_AVAILABLE) Locale("hi", "IN") else Locale.US
            } else {
                Locale.US
            }
            engine.setLanguage(fallbackLocale)
            fallbackLocale
        } else {
            desiredLocale
        }

        try {
            val voices = engine.voices ?: emptySet()
            val desiredFemale = voiceGender == VoiceGender.FEMALE
            val preferred = voices
                .filter { it.locale.language == activeLocale.language }
                .sortedByDescending { it.quality }
                .firstOrNull { voice ->
                    val name = voice.name.lowercase(Locale.ROOT)
                    if (desiredFemale) {
                        name.contains("female") || name.contains("-f") || name.contains("sfg")
                    } else {
                        name.contains("male") || name.contains("-m") || name.contains("iom")
                    }
                }
            if (preferred != null) {
                engine.voice = preferred
            }
        } catch (_: Exception) {
            // Ignore buggy Android 7.1 OEM voice enumeration
        }

        val desiredFemale = voiceGender == VoiceGender.FEMALE
        val basePitch = if (desiredFemale) 1.02f else 0.94f
        val semitoneRatio = 2.0.pow(voicePitchSemitones / 12.0).toFloat()
        engine.setPitch((basePitch * semitoneRatio).coerceIn(0.6f, 1.5f))
        engine.setSpeechRate(voiceSpeed.coerceIn(0.85f, 1.35f))
    }

    fun updateProfile(
        gender: VoiceGender,
        language: String,
        speed: Float,
        pitchSemitones: Int
    ) {
        voiceGender = gender
        languagePreference = language
        voiceSpeed = speed.coerceIn(0.85f, 1.35f)
        voicePitchSemitones = pitchSemitones.coerceIn(-4, 4)
        applyVoiceProfile()
    }

    fun setGender(gender: VoiceGender) {
        voiceGender = gender
        applyVoiceProfile()
    }

    fun setMuted(muted: Boolean) {
        _isMuted.value = muted
        if (muted) {
            stopSpeaking()
        } else if (conversationActive && !_isListening.value && !_isSpeaking.value) {
            mainHandler.postDelayed({ startListeningInternal() }, 180)
        }
    }

    fun configureCallbacks(
        onResult: (String) -> Unit,
        onAudioCaptured: (ByteArray, String) -> Unit,
        onError: (String) -> Unit
    ) {
        this.onSpeechRecognized = onResult
        this.onAudioCaptured = onAudioCaptured
        this.onSpeechError = onError
    }

    fun startListening() {
        conversationActive = true
        mainHandler.post {
            stopSpeaking()
            startListeningInternal()
        }
    }

    private fun startListeningInternal() {
        if (!conversationActive) return

        // Use direct Gemini audio capture on Android 7.1 devices lacking Google Speech Services or after client errors
        if (useDirectAudioFallback || !SpeechRecognizer.isRecognitionAvailable(context)) {
            startMediaRecorderCapture()
            return
        }

        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _isListening.value = true
                }

                override fun onBeginningOfSpeech() {
                    _isListening.value = true
                }

                override fun onRmsChanged(rmsdB: Float) {
                    val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                    _audioLevel.value = normalized
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    _isListening.value = false
                    _audioLevel.value = 0f
                }

                override fun onError(error: Int) {
                    _isListening.value = false
                    _audioLevel.value = 0f
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                            scheduleAutoResumeListening(450)
                        }
                        SpeechRecognizer.ERROR_CLIENT,
                        SpeechRecognizer.ERROR_SERVER,
                        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
                        SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> {
                            // Fall back seamlessly to direct Gemini audio capture when Android speech engine fails
                            recognizerClientErrors += 1
                            if (recognizerClientErrors >= 1) {
                                useDirectAudioFallback = true
                                startMediaRecorderCapture()
                            } else {
                                scheduleAutoResumeListening(600)
                            }
                        }
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                            conversationActive = false
                            onSpeechError?.invoke("Microphone permission is required.")
                        }
                        SpeechRecognizer.ERROR_AUDIO -> {
                            onSpeechError?.invoke("Audio recording error. Switching to backup mic...")
                            useDirectAudioFallback = true
                            scheduleAutoResumeListening(700)
                        }
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> {
                            onSpeechError?.invoke("Network timeout during speech recognition. Retrying...")
                            scheduleAutoResumeListening(1100)
                        }
                        else -> {
                            onSpeechError?.invoke("Speech recognition interrupted (code $error). Retrying...")
                            scheduleAutoResumeListening(800)
                        }
                    }
                }

                override fun onResults(results: Bundle?) {
                    recognizerClientErrors = 0
                    _isListening.value = false
                    _audioLevel.value = 0f
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spokenText = matches?.firstOrNull()?.trim().orEmpty()
                    if (spokenText.isNotEmpty()) {
                        onSpeechRecognized?.invoke(spokenText)
                    } else {
                        scheduleAutoResumeListening(350)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, resolveTargetLocale().toLanguageTag())
            putExtra(
                "android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES",
                arrayOf("en-US", "ur-PK", "hi-IN", "sd-IN", "sd-PK", "ar-SA")
            )
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {
            useDirectAudioFallback = true
            startMediaRecorderCapture()
        }
    }

    private fun startMediaRecorderCapture() {
        if (!conversationActive || isRecordingFallback) return
        stopMediaRecorderOnly(discard = true)

        val outFile = File(context.cacheDir, "anova_voice_${System.currentTimeMillis()}.m4a")
        recorderFile = outFile

        try {
            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioChannels(1)
                setAudioSamplingRate(16000)
                setAudioEncodingBitRate(64000)
                setOutputFile(outFile.absolutePath)
                prepare()
                start()
            }
            mediaRecorder = recorder
            isRecordingFallback = true
            _isListening.value = true

            val startedAt = System.currentTimeMillis()
            var speechSeen = false
            var silenceSince = 0L

            val pollRunnable = object : Runnable {
                override fun run() {
                    if (!isRecordingFallback || !conversationActive) return
                    val amp = try {
                        mediaRecorder?.maxAmplitude ?: 0
                    } catch (_: Exception) {
                        0
                    }
                    _audioLevel.value = (amp / 12000f).coerceIn(0f, 1f)
                    val now = System.currentTimeMillis()

                    if (amp > 1400) {
                        speechSeen = true
                        silenceSince = 0L
                    } else if (speechSeen) {
                        if (silenceSince == 0L) {
                            silenceSince = now
                        } else if (now - silenceSince > 1100L) {
                            finishMediaRecorderCapture(dispatch = true)
                            return
                        }
                    }

                    if (now - startedAt > 12000L) {
                        finishMediaRecorderCapture(dispatch = speechSeen)
                        return
                    }

                    mainHandler.postDelayed(this, 120L)
                }
            }
            mainHandler.postDelayed(pollRunnable, 150L)
        } catch (e: Exception) {
            isRecordingFallback = false
            _isListening.value = false
            _audioLevel.value = 0f
            outFile.delete()
            onSpeechError?.invoke("Microphone capture failed: ${e.message ?: "Audio hardware unavailable"}")
        }
    }

    private fun finishMediaRecorderCapture(dispatch: Boolean) {
        val file = recorderFile
        stopMediaRecorderOnly(discard = false)
        _isListening.value = false
        _audioLevel.value = 0f

        if (dispatch && file != null && file.exists() && file.length() > 1500) {
            try {
                val bytes = file.readBytes()
                file.delete()
                onAudioCaptured?.invoke(bytes, "audio/mp4")
                return
            } catch (_: Exception) {
            }
        }
        file?.delete()
        scheduleAutoResumeListening(300)
    }

    private fun stopMediaRecorderOnly(discard: Boolean) {
        isRecordingFallback = false
        mediaRecorder?.let { rec ->
            try {
                rec.stop()
            } catch (_: Exception) {
            }
            try {
                rec.reset()
                rec.release()
            } catch (_: Exception) {
            }
        }
        mediaRecorder = null
        if (discard) {
            recorderFile?.delete()
            recorderFile = null
        }
    }

    fun stopListening() {
        conversationActive = false
        mainHandler.post {
            _isListening.value = false
            _audioLevel.value = 0f
            if (isRecordingFallback) {
                stopMediaRecorderOnly(discard = true)
            }
            try {
                speechRecognizer?.stopListening()
            } catch (_: Exception) {
            }
        }
    }

    fun speak(text: String, audioBase64Wav: String? = null) {
        if (text.isBlank()) return
        if (_isMuted.value) {
            scheduleAutoResumeListening(350)
            return
        }

        if (!audioBase64Wav.isNullOrBlank()) {
            playBackendWav(audioBase64Wav, text)
            return
        }

        mainHandler.post {
            if (!ttsReady) {
                pendingFallbackText = text
                return@post
            }
            speakViaDeviceTts(text)
        }
    }

    private fun speakViaDeviceTts(text: String) {
        requestAudioFocus()
        applyVoiceProfile()
        val utteranceId = UUID.randomUUID().toString()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    private fun playBackendWav(base64Wav: String, fallbackText: String) {
        try {
            stopSpeaking()
            requestAudioFocus()
            val bytes = Base64.decode(base64Wav, Base64.DEFAULT)
            val tempFile = File.createTempFile("anova_tts_", ".wav", context.cacheDir)
            tempFile.writeBytes(bytes)
            mediaPlayer = MediaPlayer().apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                } else {
                    @Suppress("DEPRECATION")
                    setAudioStreamType(AudioManager.STREAM_MUSIC)
                }
                setDataSource(tempFile.absolutePath)
                setOnPreparedListener { mp ->
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        try {
                            val semitoneRatio = 2.0.pow(voicePitchSemitones / 12.0).toFloat()
                            mp.playbackParams = PlaybackParams().apply {
                                speed = voiceSpeed.coerceIn(0.85f, 1.35f)
                                pitch = semitoneRatio.coerceIn(0.6f, 1.5f)
                            }
                        } catch (_: Exception) {
                            // Some Android 7.1 OEM audio HALs restrict custom pitch; continue normal playback
                        }
                    }
                    _isSpeaking.value = true
                    _audioLevel.value = 0.7f
                    mp.start()
                }
                setOnCompletionListener {
                    _isSpeaking.value = false
                    _audioLevel.value = 0f
                    tempFile.delete()
                    abandonAudioFocus()
                    scheduleAutoResumeListening(300)
                }
                setOnErrorListener { _, _, _ ->
                    _isSpeaking.value = false
                    _audioLevel.value = 0f
                    tempFile.delete()
                    abandonAudioFocus()
                    if (ttsReady && fallbackText.isNotBlank()) {
                        mainHandler.post { speakViaDeviceTts(fallbackText) }
                    } else {
                        scheduleAutoResumeListening(400)
                    }
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            _isSpeaking.value = false
            abandonAudioFocus()
            if (ttsReady && fallbackText.isNotBlank()) {
                mainHandler.post { speakViaDeviceTts(fallbackText) }
            } else {
                scheduleAutoResumeListening(400)
            }
        }
    }

    fun stopSpeaking() {
        pendingFallbackText = null
        tts?.stop()
        mediaPlayer?.let {
            try {
                if (it.isPlaying) it.stop()
                it.release()
            } catch (_: Exception) {
            }
        }
        mediaPlayer = null
        _isSpeaking.value = false
        _audioLevel.value = 0f
        abandonAudioFocus()
    }

    fun destroy() {
        conversationActive = false
        stopMediaRecorderOnly(discard = true)
        stopSpeaking()
        speechRecognizer?.destroy()
        tts?.shutdown()
    }
}
