package com.anasmemon.anova.preferences

import android.content.Context
import com.anasmemon.anova.BuildConfig
import com.anasmemon.anova.voice.VoiceGender
import org.json.JSONArray
import org.json.JSONObject

data class AnovaChatEntry(
    val role: String,
    val text: String,
    val timestamp: Long
)

data class AnovaUserPrefs(
    val voiceGender: VoiceGender = VoiceGender.FEMALE,
    val languagePreference: String = "auto",
    val personality: String = "balanced",
    val voiceSpeed: Float = 1.08f,
    val voicePitch: Int = 0,
    val autoSpeak: Boolean = true,
    val memoryEnabled: Boolean = false,
    val backendUrl: String = BuildConfig.ANOVA_BACKEND_URL
)

class AnovaPreferencesStore(context: Context) {
    private val prefs = context.getSharedPreferences("anova_ai_prefs_v3", Context.MODE_PRIVATE)

    fun normalizeBackendUrl(raw: String?): String {
        val cleaned = raw?.trim()?.trimEnd('/').orEmpty()
        return cleaned.ifBlank { BuildConfig.ANOVA_BACKEND_URL.trimEnd('/') }
    }

    fun loadPrefs(): AnovaUserPrefs {
        val genderStr = prefs.getString("voiceGender", "female")
        val rawPersonality = prefs.getString("personality", "balanced") ?: "balanced"
        val cleanPersonality = when (rawPersonality) {
            "teacher", "professional", "balanced" -> rawPersonality
            else -> "balanced"
        }
        val storedUrl = prefs.getString("backendUrl", null)
        return AnovaUserPrefs(
            voiceGender = if (genderStr == "male") VoiceGender.MALE else VoiceGender.FEMALE,
            languagePreference = prefs.getString("languagePreference", "auto") ?: "auto",
            personality = cleanPersonality,
            voiceSpeed = prefs.getFloat("voiceSpeed", 1.08f).coerceIn(0.85f, 1.35f),
            voicePitch = prefs.getInt("voicePitch", 0).coerceIn(-4, 4),
            autoSpeak = prefs.getBoolean("autoSpeak", true),
            memoryEnabled = prefs.getBoolean("memoryEnabled", false),
            backendUrl = normalizeBackendUrl(storedUrl)
        )
    }

    fun savePrefs(p: AnovaUserPrefs) {
        prefs.edit()
            .putString("voiceGender", if (p.voiceGender == VoiceGender.MALE) "male" else "female")
            .putString("languagePreference", p.languagePreference)
            .putString("personality", p.personality)
            .putFloat("voiceSpeed", p.voiceSpeed.coerceIn(0.85f, 1.35f))
            .putInt("voicePitch", p.voicePitch.coerceIn(-4, 4))
            .putBoolean("autoSpeak", p.autoSpeak)
            .putBoolean("memoryEnabled", p.memoryEnabled)
            .putString("backendUrl", normalizeBackendUrl(p.backendUrl))
            .apply()
        if (!p.memoryEnabled) {
            clearMemoryAndHistory()
        }
    }

    fun loadMemoryFacts(): List<String> {
        val raw = prefs.getString("memoryFacts", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { arr.getString(it) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveMemoryFacts(facts: List<String>) {
        val arr = JSONArray()
        facts.takeLast(15).forEach { arr.put(it) }
        prefs.edit().putString("memoryFacts", arr.toString()).apply()
    }

    fun loadChatHistory(): List<AnovaChatEntry> {
        val raw = prefs.getString("chatHistory", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { idx ->
                val obj = arr.getJSONObject(idx)
                AnovaChatEntry(
                    role = obj.optString("role", "model"),
                    text = obj.optString("text", ""),
                    timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveChatHistory(entries: List<AnovaChatEntry>) {
        val arr = JSONArray()
        entries.takeLast(50).forEach { e ->
            arr.put(JSONObject().apply {
                put("role", e.role)
                put("text", e.text)
                put("timestamp", e.timestamp)
            })
        }
        prefs.edit().putString("chatHistory", arr.toString()).apply()
    }

    fun clearMemoryAndHistory() {
        prefs.edit()
            .remove("memoryFacts")
            .remove("chatHistory")
            .apply()
    }
}
