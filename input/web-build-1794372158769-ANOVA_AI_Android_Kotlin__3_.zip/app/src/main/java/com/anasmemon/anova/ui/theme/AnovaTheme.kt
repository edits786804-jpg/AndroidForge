package com.anasmemon.anova.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val AnovaBlue = Color(0xFF3B82F6)
val AnovaPurple = Color(0xFF8B5CF6)
val AnovaCyan = Color(0xFF06B6D4)

private val DarkColors = darkColorScheme(
    primary = AnovaCyan,
    secondary = AnovaPurple,
    tertiary = AnovaBlue,
    background = Color(0xFF050814),
    surface = Color(0xFF0B1124),
    surfaceVariant = Color(0xFF131C36),
    onBackground = Color(0xFFF1F5F9),
    onSurface = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF94A3B8)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF2563EB),
    secondary = Color(0xFF7C3AED),
    tertiary = Color(0xFF0891B2),
    background = Color(0xFFF8FAFC),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFF1F5F9),
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A),
    onSurfaceVariant = Color(0xFF475569)
)

@Composable
fun AnovaTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
